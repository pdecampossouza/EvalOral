#!/usr/bin/env python3
from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parents[1]
form=ROOT/'forms'/'anatomical_feedback_round1_v2.csv'
rows=list(csv.DictReader(form.open(encoding='utf-8')))
errors=[]
if len(rows)!=48: errors.append(f'Expected 48 cases, found {len(rows)}')
required_cols={'study_id','schema_version','round_id','rater_id','case_id','view','view_confidence_1to5','arch','arch_confidence_1to5','side','side_confidence_1to5','region','region_confidence_1to5','tooth_group','tooth_group_confidence_1to5','dentition','dentition_confidence_1to5','image_quality','instrument_present','case_review_status'}
missing=required_cols-set(rows[0]) if rows else required_cols
if missing: errors.append('Missing columns: '+', '.join(sorted(missing)))
for r in rows:
    p=ROOT/r['image_file']
    if not p.exists(): errors.append(f'Missing {p}')
html=(ROOT/'reviewer_app.html').read_text(encoding='utf-8')
for token in ['case_review_status','startedBadge','rater_id','not_assessable','not_applicable','_confidence_1to5','restoreFromCSV','restoreCsv','backupBadge','beforeunload','Save / export CSV','Array.from({length:48}','schema_version']:
    if token not in html: errors.append(f'HTML token missing: {token}')
if errors:
    print('FAIL')
    print('\n'.join(errors)); sys.exit(1)
print(f'PASS: {len(rows)} cases, multi-rater schema, partial-review tracking, CSV recovery, backup warning, confidence fields and reviewer interface verified.')
