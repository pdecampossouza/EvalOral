#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, webbrowser, threading
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
url='http://127.0.0.1:8765/reviewer_app.html'
print('EvalOral Anatomical Feedback Kit')
print('Open:', url)
threading.Timer(1.0, lambda: webbrowser.open(url)).start()
ThreadingHTTPServer(('127.0.0.1',8765), SimpleHTTPRequestHandler).serve_forever()
