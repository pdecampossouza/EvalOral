# EvalOral - Guia rapido do avaliador (Reviewer v2.3)

Este guia explica somente como abrir, salvar, interromper e recuperar uma avaliacao. Para as regras clinicas de classificacao, consulte `START_HERE_PTBR.md` e `docs/LABELING_GUIDE_PTBR.md`.

## 1. Antes de abrir

1. Extraia todo o arquivo ZIP para uma pasta do computador.
2. Nao mova somente o `reviewer_app.html` para fora da pasta: as imagens precisam permanecer junto do pacote.
3. Use o codigo de avaliador fornecido pelos pesquisadores, por exemplo `R01`. Nao use nome ou e-mail no campo `rater_id`.

## 2. Como iniciar

1. Abra `reviewer_app.html` no Chrome, Edge, Firefox ou Safari.
2. Informe o seu `rater_id` e inicie a avaliacao.
3. As respostas sao salvas automaticamente no navegador enquanto voce trabalha.

## 3. Como salvar um backup no computador

Clique periodicamente em **Salvar / exportar CSV - Save / export CSV**.

O CSV baixado e ao mesmo tempo:

- seu backup portatil;
- o arquivo usado para recuperar uma sessao;
- o arquivo parcial ou final que sera enviado aos pesquisadores.

O indicador **Backup CSV** mostra se existem respostas novas que ainda nao foram exportadas para um arquivo no computador.

## 4. Posso parar antes de 48 imagens?

Sim. Voce pode parar a qualquer momento. Antes de fechar a pagina, exporte um CSV. O sistema preserva separadamente casos `not_started`, `in_progress` e `complete`.

## 5. Como continuar depois ou recuperar respostas

Se as respostas nao aparecerem ao reabrir o HTML, ou se voce estiver usando outra copia do pacote:

1. Abra `reviewer_app.html`.
2. Clique em **Restaurar de CSV / Restore from CSV**.
3. Selecione o ultimo CSV que voce salvou.
4. O sistema recuperara o `rater_id` e as respostas e abrira no primeiro caso ainda nao concluido.
5. Continue normalmente e exporte um novo CSV depois das novas respostas.

Importante: nao e necessario refazer avaliacoes que ja estejam no CSV de backup.

## 6. Ao terminar

1. Confirme o numero de casos completos no topo da pagina.
2. Clique novamente em **Salvar / exportar CSV**.
3. Envie aos pesquisadores o CSV mais recente, normalmente com nome semelhante a `EvalOral_anatomical_R1_R01.csv`.

## Se o HTML nao abrir corretamente

Primeiro confirme que o ZIP foi extraido por completo. Se o navegador bloquear o carregamento local das imagens, consulte a secao "Se o navegador bloquear arquivos locais" em `START_HERE_PTBR.md`.

## Regra de seguranca do backup

O autosave do navegador e uma conveniencia, mas o **CSV e o backup recomendado**. Sempre exporte um CSV ao final de cada sessao de trabalho.
