# EvalOral — Anatomical Human-in-the-Loop Study (Round 1, v2)

Este pacote é o **kit cego do especialista** para um novo estudo experimental de aquisição progressiva de semântica anatômica em regras fuzzy do EvalOral.

> **Interface v2.3:** o `reviewer_app.html` é apresentado de forma consistente em **Português / English**. Os valores técnicos gravados no CSV permanecem padronizados em inglês para compatibilidade com o Admin Kit.

O especialista avalia **48 fotografias intraorais** sem visualizar regra fuzzy, PCA, cluster, coverage, rótulos anteriores ou qualquer informação que possa induzir a resposta.

## Antes de começar

1. Os autores devem atribuir a cada especialista um código simples, por exemplo `R01`, `R02`, `R03`.
2. O código deve ser usado no campo **rater_id** do formulário.
3. Não use nome, e-mail ou outro identificador pessoal no `rater_id`.
4. Especialistas diferentes podem receber exatamente o mesmo ZIP: as respostas serão mantidas separadas pelo `rater_id`.

## Objetivo do Round 1

O objetivo não é identificar FDI individual. O estudo começa pela hierarquia anatômica principal:

1. **vista**: frontal / lateral / oclusal;
2. **arcada predominante**: maxila / mandíbula / ambas;
3. **lado do paciente**: direita / esquerda / central / bilateral;
4. **região**: anterior / posterior / mista;
5. **grupo dentário predominante**: incisivos / caninos / pré-molares / molares / misto.

A **dentição** (permanente / decídua / mista) é coletada como contexto anatômico secundário. Cada conceito recebe também uma **confiança de 1 a 5** quando um rótulo anatômico é escolhido.

## Três estados que não devem ser misturados

- `uncertain`: existe informação visual, mas você não consegue escolher uma classe com segurança.
- `not_assessable`: o conceito se aplica à fotografia, mas a imagem não mostra informação suficiente para avaliá-lo.
- `not_applicable`: o conceito realmente não faz sentido para aquela fotografia. Use raramente.

Esses estados são preservados separadamente na análise. Eles não são convertidos automaticamente em uma classe anatômica.

## Como responder

1. Extraia o ZIP para uma pasta.
2. Abra `reviewer_app.html` no navegador.
3. Informe seu `rater_id`.
4. Avalie AN-001 a AN-048.
5. As respostas são salvas automaticamente **por rater_id** no navegador.
6. Salve periodicamente um backup com **Salvar / exportar CSV**.
7. Ao terminar, confirme que aparece `completos: 48/48`.
8. Gere o CSV final e envie o arquivo aos autores. O nome terá a forma `EvalOral_anatomical_R1_R01.csv`.


## Recuperar uma sessão já iniciada

Se você já exportou um CSV parcial e o navegador não mostrar mais suas respostas:

1. Abra `reviewer_app.html`.
2. Clique em **Restaurar de CSV / Restore from CSV** na tela inicial.
3. Escolha o CSV parcial que você salvou anteriormente.
4. O formulário recuperará o `rater_id`, reconstruirá as respostas e abrirá no primeiro caso ainda não concluído.

Isso também funciona com CSVs gerados pela versão v2.2 anterior. O autosave do navegador continua ativo, mas o CSV é o backup portátil recomendado caso a pasta seja movida, outro navegador seja usado ou os dados locais sejam limpos.

O indicador **Backup CSV** mostra se existem mudanças posteriores ao último arquivo exportado. Se houver respostas novas ainda sem backup, o navegador tentará avisar antes de fechar/recarregar a página.

## Regras de anotação

- Avalie somente o que pode ser sustentado pela fotografia.
- Não complete um campo por inferência indireta quando a evidência visual for insuficiente.
- Em `side`, direita/esquerda significa o **lado anatômico do paciente**, não o lado da tela.
- Em caso de possível espelhamento sem solução segura, use `uncertain`.
- Em `tooth_group`, escolha o grupo predominante visível; não identifique um dente FDI neste round.
- Marque instrumentos, afastadores ou espelhos porque eles podem interferir no aprendizado visual.
- `image_quality=unusable` não obriga a inventar rótulos anatômicos; use `not_assessable` nos conceitos que não puderem ser avaliados.

## Se o navegador bloquear arquivos locais

### Windows

```bash
py -m venv .venv
.venv\Scripts\activate
python scripts\serve.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python scripts/serve.py
```

Abra `http://127.0.0.1:8765/reviewer_app.html`.

## O que acontece depois

Os autores não simplesmente concatenam os rótulos. O Admin Kit v2 preserva cada especialista separadamente, mede concordância e discordância, constrói consenso por conceito, cria perfis semânticos ligados às regras fuzzy e testa generalização para voluntários não usados no feedback.

Leia também:

- `docs/LABELING_GUIDE_PTBR.md`
- `docs/MULTIRATER_PROTOCOL_PTBR.md`
- `docs/WHAT_HAPPENS_AFTER_FEEDBACK.md`
- `docs/RECOVERY_BACKUP_PTBR.md`


## Coleta parcial / Partial collection

Se você precisar interromper a avaliação antes de 48/48, pode exportar o CSV mesmo assim. O arquivo registra separadamente casos `not_started`, `in_progress` e `complete`. Um caso não iniciado **não** deve ser convertido em `uncertain`; ausência de avaliação e incerteza clínica são informações diferentes.

If you need to stop before 48/48, you may still export the CSV. The file distinguishes `not_started`, `in_progress`, and `complete` cases. An unstarted case is **not** converted to `uncertain`; missing review and clinical uncertainty are different states.
