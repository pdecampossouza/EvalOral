# What happens after expert feedback — v2

The returned CSV files are treated as **independent expert evidence**, not as duplicated labels to be concatenated blindly.

The Admin Kit v2 will:

1. preserve `round_id + rater_id + case_id` as the annotation identity;
2. validate completeness and detect conflicting duplicate submissions;
3. keep `uncertain`, `not_assessable`, and `not_applicable` as distinct states;
4. quantify pairwise inter-rater agreement on overlapping hard labels;
5. construct per-case, per-concept consensus while retaining support, entropy, abstention rates, and number of raters;
6. link all expert evidence to the hidden PCA/rule metadata;
7. build anatomical semantic profiles for each persistent fuzzy rule;
8. record round-wise semantic history so rule knowledge can be inspected over time;
9. evaluate each resolved anatomical target with leave-one-volunteer-out validation;
10. compare a simple semantic classifier with the evolving neuro-fuzzy learner;
11. select new cases with high semantic uncertainty and fuzzy novelty;
12. separately flag already-reviewed cases with high human disagreement for re-review/adjudication.

The scientific object is therefore not only final accuracy. The study asks how **progressive expert evidence changes the semantic state attached to persistent fuzzy rules**, when that evidence is incomplete, uncertain, or discordant.
