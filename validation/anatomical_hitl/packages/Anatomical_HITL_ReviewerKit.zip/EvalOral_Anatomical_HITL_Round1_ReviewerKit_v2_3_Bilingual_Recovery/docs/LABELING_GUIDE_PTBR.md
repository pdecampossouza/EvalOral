# Guia de anotação anatômica — v2

## Estados especiais: diferença metodológica

Estes estados **não são sinônimos**:

- `uncertain`: a característica parece observável, porém duas ou mais classes permanecem plausíveis ou a orientação é ambígua.
- `not_assessable`: a pergunta é pertinente, mas a imagem não contém informação visual suficiente para respondê-la.
- `not_applicable`: a pergunta realmente não se aplica àquela fotografia. Deve ser raro nas 48 imagens deste round.

Na análise, esses estados são preservados separadamente e excluídos do rótulo anatômico duro. Sua frequência continua sendo informação útil sobre dificuldade, qualidade e limites de inferência.

## 1. View / vista

- `frontal`: observação predominantemente de frente.
- `lateral`: observação predominantemente de um lado/hemiarco.
- `occlusal`: exposição ampla da superfície oclusal/arco.
- `other`: vista fotográfica reconhecível, mas fora das três categorias principais.
- `uncertain`: mais de uma vista permanece plausível.
- `not_assessable`: a fotografia não permite reconhecer a vista com segurança.
- `not_applicable`: use somente se a noção de vista não fizer sentido para o caso.

## 2. Arch / arcada

- `maxilla`: predominância da arcada superior.
- `mandible`: predominância da arcada inferior.
- `both`: ambas são relevantes/visíveis.
- `uncertain`: há evidência, mas não é possível decidir a classe.
- `not_assessable`: a arcada não pode ser avaliada pela informação visível.
- `not_applicable`: use raramente, somente quando a pergunta não se aplicar.

## 3. Side / lado do paciente

- `right`: lado direito anatômico do paciente.
- `left`: lado esquerdo anatômico do paciente.
- `central`: região predominantemente mediana/anterior, sem lateralidade útil.
- `bilateral`: ambos os lados são relevantes.
- `uncertain`: lateralidade parece pertinente, mas orientação/espelhamento impede decisão segura.
- `not_assessable`: não há informação suficiente para determinar lateralidade.
- `not_applicable`: lateralidade realmente não é um conceito aplicável ao caso; use raramente.

**Atenção:** não assuma que o lado esquerdo da tela corresponde automaticamente ao lado direito do paciente.

## 4. Region / região

- `anterior`: região anterior predominante.
- `posterior`: região posterior predominante.
- `mixed`: anterior e posterior aparecem de forma relevante.
- `uncertain`, `not_assessable`, `not_applicable`: conforme definições acima.

## 5. Tooth group / grupo dentário predominante

- `incisors`
- `canines`
- `premolars`
- `molars`
- `mixed`
- `uncertain`
- `not_assessable`
- `not_applicable`

Não identifique FDI 11, 12, 16 etc. neste round.

## 6. Dentition / dentição

- `permanent`
- `deciduous`
- `mixed`
- `uncertain`
- `not_assessable`
- `not_applicable`

## Confiança por conceito

Quando você escolhe um rótulo anatômico real, o formulário pede confiança de `1` a `5`:

- `1`: muito baixa;
- `2`: baixa;
- `3`: moderada;
- `4`: alta;
- `5`: muito alta.

A confiança não é solicitada para `uncertain`, `not_assessable` ou `not_applicable`, porque esses estados já expressam uma forma de abstenção explícita.

## 7. Image usefulness / qualidade

- `adequate`: suficiente para interpretação anatômica.
- `limited`: ainda permite alguma interpretação, com limitações relevantes.
- `unusable`: a fotografia não sustenta interpretação anatômica confiável.

## 8. Instrument present

- `no`
- `yes_minor`: instrumento/afastador/espelho visível, mas não dominante.
- `yes_major`: o objeto interfere substancialmente na região anatômica.
