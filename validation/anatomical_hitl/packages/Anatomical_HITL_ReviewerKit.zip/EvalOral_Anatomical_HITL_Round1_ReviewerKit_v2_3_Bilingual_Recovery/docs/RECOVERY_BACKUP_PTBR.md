# Recuperação de sessão e backup / Session recovery and backup

O `reviewer_app.html` salva cada alteração automaticamente no armazenamento local do navegador. Esse autosave é conveniente, mas **não deve ser tratado como único backup**: ao abrir outra cópia do HTML, mover a pasta, trocar de navegador ou limpar dados locais, o navegador pode não disponibilizar a sessão anterior.

## Backup recomendado

Use **Salvar / exportar CSV** periodicamente e ao final de cada sessão. O mesmo CSV serve como:

- backup portátil da sessão;
- arquivo de recuperação;
- entrega parcial ou final aos autores.

O navegador não pode, por segurança, gravar silenciosamente um arquivo no computador sem uma ação do usuário. Por isso o formulário combina autosave local com backup CSV explícito.

## Como recuperar

1. Abra `reviewer_app.html`.
2. Na tela inicial, clique em **Restaurar de CSV / Restore from CSV**.
3. Selecione o CSV parcial previamente exportado, por exemplo `EvalOral_anatomical_R1_R01.csv`.
4. O formulário lê o `rater_id`, reconstrói as respostas já existentes e abre no primeiro caso ainda não concluído.
5. Continue normalmente e gere um novo CSV antes de fechar após novas respostas.

A restauração aceita os CSVs do Reviewer v2.2 e da versão v2.3 de recuperação, mantendo o schema científico `2.2` para compatibilidade com o Admin Kit.

## Aviso ao fechar

Se houver alterações feitas depois do último backup CSV, o navegador tentará apresentar um aviso antes de fechar/recarregar a página. Alguns navegadores mostram uma mensagem genérica própria. O indicador **Backup CSV** informa se o backup está atualizado ou pendente.
