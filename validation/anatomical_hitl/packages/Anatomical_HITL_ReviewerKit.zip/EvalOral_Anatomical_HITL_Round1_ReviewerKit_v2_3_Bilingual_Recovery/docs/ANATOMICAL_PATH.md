# From photographic view to anatomy-aware fuzzy knowledge

Round 1 evaluates whether persistent visual regions can progressively acquire anatomical meaning.

```text
Dental photograph
    ↓
Persistent visual fuzzy region
    ↓
View
frontal / lateral / occlusal
    ↓
Arch
maxilla / mandible / both
    ↓
Patient side
right / left / central / bilateral
    ↓
Region
anterior / posterior / mixed
    ↓
Dominant tooth group
incisors / canines / premolars / molars / mixed
    ↓
Dentition
permanent / deciduous / mixed
    ↓
Future work: tooth-instance segmentation and FDI identity
```

The hierarchy is intentionally coarse at first. Reliable context can later constrain tooth-level reasoning, while disagreement and explicit abstention indicate where the representation or the photograph does not yet support a reliable anatomical statement.
