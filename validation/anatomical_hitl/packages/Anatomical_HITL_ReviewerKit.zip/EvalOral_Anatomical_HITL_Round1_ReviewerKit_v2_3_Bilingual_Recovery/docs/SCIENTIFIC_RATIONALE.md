# Scientific rationale — new human-in-the-loop study

This package is designed as the first round of a **new EvalOral human-in-the-loop study**, not as an additional experiment required by the original EvalOral manuscript.

The starting hypothesis is that persistent fuzzy regions learned from oral photographs may contain reusable visual organization before they possess explicit odontological meaning. Expert feedback is therefore introduced as a semantic evidence stream layered over the existing rule geometry.

The initial hierarchy is deliberately coarse:

```text
image
  -> view
  -> arch
  -> patient side
  -> anterior/posterior region
  -> tooth group
  -> future tooth instance / FDI identity

secondary context: dentition
```

The study distinguishes two possible forms of evolution:

1. **semantic evolution** — the geometry of a fuzzy rule remains fixed while accumulated expert evidence changes what the rule is understood to mean;
2. **structural evolution** — persistent semantic conflict may later motivate rule splitting, new-rule creation, premise adaptation, or other geometric change.

Round 1 is primarily designed to test semantic evolution first. This protects the interpretation: if an existing fuzzy region acquires stable anatomical meaning across held-out volunteers, that meaning cannot be attributed simply to a geometry refit on the same expert labels.

Multiple experts are supported because disagreement is itself informative. The analysis preserves individual annotations, confidence, abstention states, consensus support, and semantic entropy instead of replacing all evidence with a single majority label at ingestion time.
