# Protocolo multi-especialista

## Unidade de anotação

Cada registro é identificado por:

```text
round_id + rater_id + case_id
```

Portanto, a mesma fotografia pode ter várias respostas independentes sem que uma sobrescreva a outra.

## Exemplo

```text
R1 | R01 | AN-017 | lateral | maxilla | right     | posterior | molars
R1 | R02 | AN-017 | lateral | maxilla | uncertain | posterior | molars
R1 | R03 | AN-017 | lateral | maxilla | right     | posterior | premolars
```

Essas três linhas não devem ser reduzidas manualmente antes da análise.

## Por que preservar discordância

O estudo pretende separar pelo menos três situações:

1. **especialistas concordam e o modelo está incerto** — incerteza predominantemente computacional;
2. **modelo está confiante e especialistas discordam** — possível confiança espúria ou região semanticamente ambígua;
3. **modelo e especialistas estão incertos** — caso potencialmente intrinsecamente difícil ou pouco avaliável.

O Admin Kit calcula consenso apenas como uma camada derivada. As respostas originais permanecem preservadas.

## Identificação dos avaliadores

Use códigos como `R01`, `R02`, `R03`. Não coloque nomes ou e-mails no arquivo de anotação. Se os autores precisarem manter uma tabela de correspondência para fins administrativos, ela deve ficar separada dos dados de análise.
