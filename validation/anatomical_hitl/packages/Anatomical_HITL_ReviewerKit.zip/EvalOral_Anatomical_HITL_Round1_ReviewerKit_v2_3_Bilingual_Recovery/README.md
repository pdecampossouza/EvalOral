# EvalOral Anatomical Human-in-the-Loop — Reviewer Kit v2.3 (Bilingual UI + Recovery + Partial Review Tracking)

Start with `START_HERE_PTBR.md`, then open `reviewer_app.html`.

This reviewer package is blinded: it does not contain the administrative key linking cases to fuzzy rules, PCA coordinates, clusters, rule coverage, released labels, or original source paths.

Interface note:

- `reviewer_app.html` now presents all reviewer-facing instructions, questions, response options, buttons, status messages, and warnings consistently in **Portuguese / English**.
- Machine-readable CSV values remain unchanged (e.g., `maxilla`, `uncertain`, `not_assessable`), so the Admin Kit v2.3 remains fully compatible.

Main v2 changes:

- multi-rater support through `rater_id`;
- fixed `round_id=R1` and `schema_version=2.2` in exports;
- separate `uncertain`, `not_assessable`, and `not_applicable` states;
- per-concept confidence scores for substantive anatomical labels;
- export identity `round_id + rater_id + case_id`;
- resumable browser storage isolated by rater ID;
- **Restore from CSV**: a previously exported partial CSV can reconstruct the browser session and resume at the first unfinished case;
- explicit CSV-backup status plus a close/reload warning when there are changes newer than the last exported backup.


Partial collections are explicitly supported. Each exported case now carries `case_review_status` = `not_started`, `in_progress`, or `complete`. An expert may therefore return, for example, 30 completed cases while another returns 48; unstarted cases are not interpreted as `uncertain` and are excluded from that rater's agreement denominator.


Recovery note: browser autosave is convenient but not portable across all file locations/browsers. Reviewers should periodically export a CSV. See `docs/RECOVERY_BACKUP_PTBR.md`.
