# EvalOral Anatomical Human-in-the-Loop — Admin Kit v2.3

**Do not send this package to reviewers.**

This package contains the hidden key linking blinded cases to volunteer IDs, PCA coordinates, persistent fuzzy-rule IDs, rule coverage, clusters, released metadata, and source paths.

The v2 package is designed for a **new multi-expert, multi-round human-in-the-loop study**. It preserves individual expert evidence first and derives consensus only as a secondary analysis layer.

## Fast visual inspection — new in Admin v2.3

Open `admin_dashboard.html` directly in a modern browser. You can drag/drop or select one or more reviewer CSV files. The dashboard reads them **locally in the browser** and provides immediate inspection before any Python analysis:

- reviewer completion and partial-review status;
- classification distributions and confidence by reviewer;
- photograph-level coverage, consensus, disagreement, and semantic entropy;
- direct display of the blinded photograph with all individual rater votes;
- hidden admin metadata for the selected photograph (volunteer block, fuzzy rule ID/coverage, clusters, and PC1-PC4);
- pairwise overlap, hard-label agreement, and Cohen kappa;
- ingestion QA for duplicate annotations, unknown case IDs, schema versions, rater IDs, and labels;
- export of a quick photograph-level inspection summary.

The dashboard is an **inspection layer**, not the canonical scientific analysis engine. Final tables for the paper must still be generated with `validate_feedback.py` and `analyze_feedback.py`. This separation prevents browser-side convenience logic from becoming the authoritative analysis pipeline.

The 48 blinded photographs are included inside the Admin package under `images/` solely so authors can inspect a case visually while comparing expert votes.

## Main methodological changes in v2

- accepts **multiple reviewer CSV files** in one run;
- identifies each annotation by `round_id + rater_id + case_id`;
- preserves `uncertain`, `not_assessable`, and `not_applicable` separately;
- uses confidence **per anatomical concept**;
- detects duplicate/conflicting submissions;
- supports unequal/partial reviewer completion without treating unreviewed cases as `uncertain`;
- reports rater completeness and pairwise agreement on true overlap only;
- produces classification statistics by reviewer and by photograph;
- builds per-case consensus with support and semantic entropy;
- attaches expert evidence to persistent fuzzy-rule IDs;
- creates a round-wise `semantic_rule_history.csv`;
- creates `rule_semantic_state.json`, a persistent semantic sidecar for the fuzzy rule inventory;
- performs leave-one-volunteer-out evaluation on resolved case-level labels;
- separates **new-case active learning** from **human-disagreement re-review**.

## Important boundary

`rule_semantic_state.json` updates the **semantic knowledge attached to saved rule IDs**. It does **not** move the Gaussian centers or widths of the original fuzzy premises.

This is intentional for the first experimental phase: semantic evolution is tested before structural evolution. A later phase can test whether persistent expert conflict should trigger rule splitting, new-rule creation, or premise adaptation.

## Recommended folder use

Place all returned reviewer CSV files in:

```text
feedbacks/
```

For example:

```text
feedbacks/
  EvalOral_anatomical_R1_R01.csv
  EvalOral_anatomical_R1_R02.csv
  EvalOral_anatomical_R1_R03.csv
```

Do **not** concatenate these manually.

## Environment

```bash
python -m venv .venv
source .venv/bin/activate        # Linux/macOS
# .venv\Scripts\activate       # Windows
pip install -r requirements_analysis.txt
```

## Step 1 — validate the returned files

```bash
python scripts/validate_feedback.py feedbacks/
```

This checks rater IDs, rounds, partial/completed review status, explicit abstention states, and duplicate submissions. Empty exported rows are treated as `not_started`, not as expert uncertainty.

## Step 2 — analyze all experts together

```bash
python scripts/analyze_feedback.py feedbacks/
```

You may also pass files explicitly:

```bash
python scripts/analyze_feedback.py feedbacks/R01.csv feedbacks/R02.csv feedbacks/R03.csv
```

### Core outputs

Written to `analysis/completed_feedback_analysis_v2/`:

```text
raw_annotations_normalized.csv
current_annotation_state_by_rater.csv
ingestion_qa.csv
rater_completeness.csv
rater_round_statistics.csv
rater_classification_statistics.csv
rater_label_distribution.csv
rater_label_distribution_all_rounds.csv

photo_rater_coverage.csv
photo_rater_votes_long.csv
photo_classification_statistics.csv
photo_summary_statistics.csv
review_statistics_report.html

pairwise_rater_agreement.csv
inter_rater_summary.csv
consensus_long.csv
consensus_wide.csv
consensus_label_distribution.csv
human_disagreement_cases.csv
case_rule_human_signals.csv

semantic_rule_profiles.csv
semantic_rule_label_distribution.csv
semantic_rule_history.csv
semantic_rule_evolution_events.csv
rule_semantic_state.json

merged_consensus_with_features.csv
heldout_volunteer_metrics.csv
heldout_volunteer_predictions.csv
analysis_manifest.json
```

## Consensus policy

Consensus is **derived, not ingested**.

For each `case_id × anatomical concept`:

- `uncertain`, `not_assessable`, `not_applicable`, missing values, and `view=other` are not treated as hard anatomical classes;
- one valid rater produces a label with status `single_rater`;
- with two or more valid raters, a unique label must reach at least `0.60` of valid votes to receive status `consensus`;
- otherwise the concept is `unresolved` and is excluded from hard-label generalization tests;
- confidence scores are reported but **do not allow one highly confident rater to override multiple peers**.

The original individual annotations always remain available.

## Step 3 — held-out volunteer evaluation

The analysis evaluates each concept separately using the existing `PC1–PC4` representation and `volunteer_id` groups.

The main subset is `all_resolved`. Additional sensitivity analyses may appear when enough data are available:

- `adequate_images_only`;
- `multi_rater_high_consensus`.

The comparison remains:

```text
Logistic Regression semantic baseline
                versus
Evolving Neuro-Fuzzy semantic learner
```

## Step 4 — inspect fuzzy-rule semantic evolution

`semantic_rule_profiles.csv` summarizes, for every persistent `final_rule_id` and anatomical concept:

- top expert-supported label;
- label share;
- semantic entropy;
- number of cases and raters;
- `uncertain`, `not_assessable`, and `not_applicable` rates;
- confidence and average fuzzy coverage.

`semantic_rule_history.csv` repeats this state cumulatively by round.

`rule_semantic_state.json` is the machine-readable semantic state that can be carried forward with the rule inventory.

## Step 5 — select the next round

```bash
python scripts/select_next_round.py feedbacks/ --n 24
```

Outputs are written to `analysis/round2_selection_v2/`:

- `round2_new_candidates.csv`: unseen cases ranked by
  `0.7 × semantic uncertainty + 0.3 × fuzzy novelty`, with volunteer/cluster diversity limits;
- `rereview_candidates.csv`: already-reviewed cases prioritized because of expert disagreement, unresolved consensus, abstention, or need for a second opinion.

These are intentionally different queues:

```text
new case     -> "the model needs more information"
re-review    -> "the human evidence is weak or conflicting"
```

## Multi-round use

Future exports should keep the same `rater_id` for the same expert and change `round_id` (`R2`, `R3`, ...). The analysis retains round history and uses the most recent annotation from each rater/case as the current state while preserving earlier rounds for the semantic-history analysis.

## Scientific interpretation

The primary question is not whether 48 labels produce a perfect anatomical classifier. It is whether progressive expert evidence can transform an already discovered visual fuzzy-rule space into increasingly stable anatomical knowledge, and whether that knowledge transfers across photographed volunteers.

## Design audit specific to the current 48 cases

Read `DESIGN_AUDIT_BEFORE_LAUNCH.md` before launch. The current 48 cases and the current 121-image active pool are drawn from the permanent-dentition DAI source module. Accordingly, `dentition` is best treated as a secondary context field in this Round 1 rather than a primary discriminative endpoint unless the sampling frame is broadened.


## Unequal reviewer completion — supported

Example: R01 completes 30/48 photographs and R02 completes 48/48. The Admin Kit keeps all available evidence. R01 contributes to agreement only on the photographs that R01 actually started; the remaining photographs may retain a `single_rater` label from R02. `multi_rater_high_consensus` analyses require multiple valid raters and therefore do not silently treat those single-rater cases as multi-rater evidence.

Run `python scripts/self_test_partial_raters.py` to execute a software-only 30-versus-48 regression test.
