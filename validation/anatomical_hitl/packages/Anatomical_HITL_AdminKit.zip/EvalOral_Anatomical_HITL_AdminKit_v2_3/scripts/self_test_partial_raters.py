#!/usr/bin/env python3
"""Software QA for unequal reviewer completion (30/48 versus 48/48).

Uses only the synthetic SOFTWARE_QA_v2 reviewer files bundled with the Admin
Kit. The generated labels are not scientific results.
"""
from pathlib import Path
import tempfile
import pandas as pd

from feedback_utils import load_feedback, annotation_completeness, pairwise_agreement, build_consensus_long

ROOT=Path(__file__).resolve().parents[1]
QA=ROOT/'analysis'/'SOFTWARE_QA_v2'/'inputs'


def main():
    a=pd.read_csv(QA/'QA_RQA1.csv',dtype=str,keep_default_na=False)
    b=pd.read_csv(QA/'QA_RQA2.csv',dtype=str,keep_default_na=False)
    a=a[a.round_id.eq('R1')].copy().reset_index(drop=True)
    b=b[b.round_id.eq('R1')].copy().reset_index(drop=True)
    a['rater_id']='QA_PART30'; b['rater_id']='QA_FULL48'
    a['schema_version']='2.2'; b['schema_version']='2.2'
    for df in (a,b):
        if 'case_review_status' not in df.columns:
            df.insert(df.columns.get_loc('image_file')+1,'case_review_status','complete')
        else:
            df['case_review_status']='complete'
    blank_cols=[c for c in a.columns if c in {
        'view','view_confidence_1to5','arch','arch_confidence_1to5','side','side_confidence_1to5',
        'region','region_confidence_1to5','tooth_group','tooth_group_confidence_1to5',
        'dentition','dentition_confidence_1to5','image_quality','instrument_present','notes'
    }]
    for c in blank_cols:
        a.loc[30:,c]=''
    a.loc[30:,'case_review_status']='not_started'

    with tempfile.TemporaryDirectory() as td:
        td=Path(td); a.to_csv(td/'part30.csv',index=False); b.to_csv(td/'full48.csv',index=False)
        fb,_=load_feedback([str(td)])
        comp=annotation_completeness(fb).set_index('rater_id')
        assert int(comp.loc['QA_PART30','n_cases_started'])==30
        assert int(comp.loc['QA_PART30','n_cases_complete'])==30
        assert int(comp.loc['QA_PART30','n_cases_not_started'])==18
        assert int(comp.loc['QA_FULL48','n_cases_started'])==48
        pair,_=pairwise_agreement(fb)
        assert set(pair.n_overlap_started_cases.astype(int))=={30}
        cons=build_consensus_long(fb)
        late=cons[(cons.case_id=='AN-031') & (cons.field=='view')].iloc[0]
        assert int(late.n_total_raters)==1
        assert int(late.n_not_started_raters)==1
        assert late.consensus_status=='single_rater'
        early=cons[(cons.case_id=='AN-001') & (cons.field=='view')].iloc[0]
        assert int(early.n_total_raters)==2
    print('PASS: partial reviewer coverage 30/48 vs 48/48 handled without counting not_started as uncertainty or pairwise overlap.')


if __name__=='__main__':
    main()
