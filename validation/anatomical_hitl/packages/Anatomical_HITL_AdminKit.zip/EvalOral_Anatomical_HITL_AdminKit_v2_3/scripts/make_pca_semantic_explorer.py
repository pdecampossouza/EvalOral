#!/usr/bin/env python3
"""Create an author-side PCA semantic explorer.

This figure must remain hidden from blinded reviewers until annotation is complete.
"""
from pathlib import Path
import argparse
import pandas as pd
from PIL import Image, ImageOps, ImageDraw, ImageFont


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('dedup_assignments_csv',help='CSV containing PC1-PC4 and image_path')
    ap.add_argument('--out',default=None)
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    src=Path(args.dedup_assignments_csv)
    if not src.exists(): raise SystemExit(f'File not found: {src}')
    df=pd.read_csv(src)
    required={'PC1','PC2','PC3','PC4','image_path'}
    missing=required-set(df.columns)
    if missing: raise SystemExit('Missing columns: '+', '.join(sorted(missing)))
    try:
        titlef=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',24)
        small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    except Exception:
        titlef=small=ImageFont.load_default()
    W,H=1600,1000; can=Image.new('RGB',(W,H),'white'); draw=ImageDraw.Draw(can)
    draw.text((W//2,20),'PCA semantic explorer: real images at low and high component extremes',anchor='ma',fill='black',font=titlef)
    cellw,cellh=170,120
    for row,pc in enumerate(['PC1','PC2','PC3','PC4']):
        y=90+row*220; draw.text((25,y+55),pc,fill='black',font=titlef)
        lows=df.nsmallest(4,pc); highs=df.nlargest(4,pc)
        draw.text((160,y),'LOW',fill='black',font=small); draw.text((900,y),'HIGH',fill='black',font=small)
        for group,x0 in [(lows,160),(highs,900)]:
            for k,(_,r) in enumerate(group.iterrows()):
                p=Path(r.image_path)
                if not p.exists(): continue
                im=Image.open(p).convert('RGB'); im=ImageOps.fit(im,(cellw,cellh),method=Image.Resampling.LANCZOS)
                x=x0+k*(cellw+12); can.paste(im,(x,y+30)); draw.text((x+cellw/2,y+154),f'{r[pc]:.2f}',anchor='ma',fill='black',font=small)
    out=Path(args.out) if args.out else root/'analysis'/'PCA_semantic_explorer.png'
    out.parent.mkdir(parents=True,exist_ok=True); can.save(out); print(out)

if __name__=='__main__': main()
