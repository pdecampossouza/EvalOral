#!/usr/bin/env python3
"""Shared utilities for EvalOral anatomical human-in-the-loop analysis v2.

The utilities preserve individual rater evidence and derive consensus as a
separate analysis layer. They do not perform clinical diagnosis.
"""
from __future__ import annotations

from pathlib import Path
from itertools import combinations
import glob
import json
import math
import re
from typing import Iterable, List, Tuple, Dict

import numpy as np
import pandas as pd
from sklearn.metrics import cohen_kappa_score

SCHEMA_VERSION = "2.2"
TARGETS = ["view", "arch", "side", "region", "tooth_group", "dentition"]
CONTROLS = ["image_quality", "instrument_present"]
LABEL_FIELDS = TARGETS + CONTROLS
FEATURES = ["PC1", "PC2", "PC3", "PC4"]

VALID_LABELS: Dict[str, set] = {
    "view": {"frontal", "lateral", "occlusal"},
    "arch": {"maxilla", "mandible", "both"},
    "side": {"right", "left", "central", "bilateral"},
    "region": {"anterior", "posterior", "mixed"},
    "tooth_group": {"incisors", "canines", "premolars", "molars", "mixed"},
    "dentition": {"permanent", "deciduous", "mixed"},
    "image_quality": {"adequate", "limited", "unusable"},
    "instrument_present": {"no", "yes_minor", "yes_major"},
}
ABSTENTION_STATES = {"uncertain", "not_assessable", "not_applicable"}
SPECIAL_EXCLUDED = {"view": {"other"}}
CASE_REVIEW_STATES = {"not_started", "in_progress", "complete"}


def _clean_text(v) -> str:
    if pd.isna(v):
        return ""
    return str(v).strip()


def infer_case_review_status_from_row(row) -> str:
    """Infer review status from actual annotation content, not CSV row presence.

    Reviewer exports contain one row for every blinded case. Therefore an empty
    row means the case was not reviewed, not that the rater abstained.
    """
    substantive = []
    for field in LABEL_FIELDS:
        substantive.append(_clean_text(row.get(field, "")))
    for target in TARGETS:
        substantive.append(_clean_text(row.get(f"{target}_confidence_1to5", "")))
    substantive.append(_clean_text(row.get("notes", "")))
    if not any(substantive):
        return "not_started"

    complete = True
    for target in TARGETS:
        v = _clean_text(row.get(target, "")).lower()
        if not v or (v not in VALID_LABELS[target] and v not in ABSTENTION_STATES and v not in SPECIAL_EXCLUDED.get(target, set())):
            complete = False
            continue
        if v not in ABSTENTION_STATES and _clean_text(row.get(f"{target}_confidence_1to5", "")) == "":
            complete = False
    for control in CONTROLS:
        if _clean_text(row.get(control, "")).lower() not in VALID_LABELS[control]:
            complete = False
    return "complete" if complete else "in_progress"


def round_rank(v: str) -> Tuple[int, str]:
    s = _clean_text(v)
    m = re.search(r"(\d+)", s)
    return (int(m.group(1)) if m else 10**9, s)


def expand_feedback_inputs(inputs: Iterable[str]) -> List[Path]:
    files: List[Path] = []
    for raw in inputs:
        p = Path(raw)
        if p.is_dir():
            files.extend(sorted(x for x in p.glob("*.csv") if x.is_file()))
        elif any(ch in raw for ch in "*?["):
            files.extend(sorted(Path(x) for x in glob.glob(raw) if Path(x).is_file()))
        elif p.is_file():
            files.append(p)
        else:
            raise FileNotFoundError(f"Feedback input not found: {raw}")
    # stable de-duplication by resolved path
    seen, out = set(), []
    for p in files:
        rp = str(p.resolve())
        if rp not in seen:
            seen.add(rp); out.append(p)
    if not out:
        raise ValueError("No feedback CSV files found.")
    return out


def _normalize_one(path: Path, file_index: int) -> Tuple[pd.DataFrame, List[dict]]:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    issues: List[dict] = []
    if "case_id" not in df.columns:
        raise ValueError(f"{path.name}: missing required column case_id")

    # Backward compatibility with v1 exports.
    if "schema_version" not in df.columns:
        df["schema_version"] = "1.0"
        issues.append({"severity":"info","file":path.name,"issue":"legacy_schema_assumed","detail":"schema_version=1.0"})
    if "study_id" not in df.columns:
        df["study_id"] = "EvalOral_Anatomical_HITL"
    if "round_id" not in df.columns:
        df["round_id"] = "R1"
        issues.append({"severity":"info","file":path.name,"issue":"round_id_assumed","detail":"R1"})
    if "rater_id" not in df.columns:
        inferred = f"LEGACY_{file_index:02d}"
        df["rater_id"] = inferred
        issues.append({"severity":"warning","file":path.name,"issue":"rater_id_missing","detail":f"inferred {inferred}"})
    else:
        df["rater_id"] = df["rater_id"].map(_clean_text)
        blank = df["rater_id"].eq("")
        if blank.any():
            inferred = f"LEGACY_{file_index:02d}"
            df.loc[blank,"rater_id"] = inferred
            issues.append({"severity":"warning","file":path.name,"issue":"blank_rater_id","detail":f"blank rows assigned {inferred}"})

    for field in LABEL_FIELDS:
        if field not in df.columns:
            df[field] = ""
        df[field] = df[field].map(lambda x: _clean_text(x).lower())

    # Old image quality vocabulary.
    df.loc[df["image_quality"].eq("not_assessable"), "image_quality"] = "unusable"

    for target in TARGETS:
        c = f"{target}_confidence_1to5"
        if c not in df.columns:
            if "confidence_1to5" in df.columns:
                df[c] = df["confidence_1to5"]
                issues.append({"severity":"info","file":path.name,"issue":"legacy_global_confidence_reused","detail":c})
            else:
                df[c] = ""
        df[c] = df[c].map(_clean_text)

    for col in ["case_started_at_utc", "case_last_modified_utc", "notes", "annotation_id", "image_file"]:
        if col not in df.columns:
            df[col] = ""

    exported_status = df["case_review_status"].map(lambda x: _clean_text(x).lower()) if "case_review_status" in df.columns else pd.Series([""]*len(df), index=df.index)
    inferred_status = df.apply(infer_case_review_status_from_row, axis=1)
    if "case_review_status" not in df.columns:
        issues.append({"severity":"info","file":path.name,"issue":"case_review_status_inferred","detail":"legacy export: inferred from actual annotation content"})
    else:
        bad_status = ~exported_status.isin(CASE_REVIEW_STATES | {""})
        if bad_status.any():
            issues.append({"severity":"warning","file":path.name,"issue":"unknown_case_review_status","detail":",".join(sorted(set(exported_status[bad_status])))})
        mismatch = exported_status.isin(CASE_REVIEW_STATES) & exported_status.ne(inferred_status)
        if mismatch.any():
            issues.append({"severity":"warning","file":path.name,"issue":"case_review_status_recomputed","detail":f"{int(mismatch.sum())} row(s) disagreed with annotation content"})
    # The analytic status is always recomputed from content so partial exports are
    # safe even when older reviewer HTML exported all 48 rows.
    df["case_review_status"] = inferred_status

    df["case_id"] = df["case_id"].map(_clean_text)
    df["round_id"] = df["round_id"].map(_clean_text).replace("", "R1")
    df["source_feedback_file"] = path.name
    return df, issues


def load_feedback(inputs: Iterable[str]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    paths = expand_feedback_inputs(inputs)
    frames, issues = [], []
    for i, p in enumerate(paths, 1):
        d, q = _normalize_one(p, i)
        frames.append(d); issues.extend(q)
    df = pd.concat(frames, ignore_index=True, sort=False)
    df = df[df["case_id"].ne("")].copy()

    # Validate known label vocabulary but keep rows for QA.
    for field in LABEL_FIELDS:
        allowed = set(VALID_LABELS[field]) | ABSTENTION_STATES | SPECIAL_EXCLUDED.get(field, set()) | {""}
        bad = sorted(set(df[field]) - allowed)
        for val in bad:
            issues.append({"severity":"warning","file":"multiple","issue":"unknown_label","detail":f"{field}={val}"})

    # Resolve duplicate submissions for the same rater/round/case.
    id_cols = ["round_id", "rater_id", "case_id"]
    analytic_cols = LABEL_FIELDS + [f"{t}_confidence_1to5" for t in TARGETS] + ["notes"]
    keep_indices = []
    for key, g in df.groupby(id_cols, sort=False, dropna=False):
        if len(g) == 1:
            keep_indices.append(g.index[0]); continue
        unique_analytic = g[analytic_cols].drop_duplicates()
        if len(unique_analytic) == 1:
            keep_indices.append(g.index[-1])
            issues.append({"severity":"info","file":"multiple","issue":"exact_duplicate_removed","detail":"|".join(map(str,key))})
            continue
        ts = pd.to_datetime(g["case_last_modified_utc"], errors="coerce", utc=True)
        if ts.notna().any():
            chosen = ts.idxmax()
            keep_indices.append(chosen)
            issues.append({"severity":"warning","file":"multiple","issue":"conflicting_duplicate_latest_kept","detail":"|".join(map(str,key))})
        else:
            raise ValueError(
                "Conflicting duplicate annotations without timestamps for "
                f"round_id={key[0]}, rater_id={key[1]}, case_id={key[2]}. "
                "Keep only the final submission for that rater/round/case."
            )
    df = df.loc[sorted(keep_indices)].reset_index(drop=True)
    qa = pd.DataFrame(issues, columns=["severity","file","issue","detail"])
    return df, qa


def is_valid_label(field: str, value: str) -> bool:
    return _clean_text(value).lower() in VALID_LABELS[field]


def label_status(field: str, value: str) -> str:
    v = _clean_text(value).lower()
    if v == "": return "missing"
    if v in ABSTENTION_STATES: return v
    if v in SPECIAL_EXCLUDED.get(field, set()): return "other"
    if v in VALID_LABELS[field]: return "valid"
    return "unknown"


def latest_annotation_state(df: pd.DataFrame, through_round: str | None = None) -> pd.DataFrame:
    d = df.copy()
    if through_round is not None:
        max_rank = round_rank(through_round)
        d = d[d["round_id"].map(round_rank).map(lambda x: x <= max_rank)].copy()
    d["_round_rank"] = d["round_id"].map(round_rank)
    d["_ts"] = pd.to_datetime(d["case_last_modified_utc"], errors="coerce", utc=True)
    # stable sort; later round wins; within round, later timestamp wins.
    d = d.sort_values(["rater_id","case_id","_round_rank","_ts"], na_position="first")
    d = d.groupby(["rater_id","case_id"], as_index=False, sort=False).tail(1)
    return d.drop(columns=["_round_rank","_ts"]).reset_index(drop=True)


def normalized_entropy_from_counts(counts: Dict[str, int]) -> float:
    vals = np.asarray([v for v in counts.values() if v > 0], dtype=float)
    if len(vals) <= 1: return 0.0
    p = vals / vals.sum()
    return float(-(p*np.log(p)).sum() / np.log(len(vals)))


def build_consensus_long(df: pd.DataFrame, min_support: float = 0.60) -> pd.DataFrame:
    rows = []
    d = latest_annotation_state(df)
    n_raters_loaded = int(d["rater_id"].nunique())
    for case_id, g_all in d.groupby("case_id", sort=True):
        started_mask = g_all["case_review_status"].ne("not_started")
        g = g_all[started_mask].copy()
        n_started = int(g["rater_id"].nunique())
        n_not_started = int(g_all.loc[~started_mask, "rater_id"].nunique())
        for field in LABEL_FIELDS:
            statuses = g[field].map(lambda x: label_status(field,x)) if n_started else pd.Series(dtype=str)
            valid = g[statuses.eq("valid")].copy() if n_started else g.copy()
            counts = valid[field].value_counts().to_dict() if n_started else {}
            n_valid = int(len(valid))
            n_responses = int((~statuses.isin(["missing","unknown"])).sum()) if n_started else 0
            top_label, top_n, support = "", 0, np.nan
            status = "no_valid_label"
            if n_valid:
                top_n = int(max(counts.values()))
                top_labels = sorted([lab for lab,n in counts.items() if n == top_n])
                support = top_n / n_valid
                if n_valid == 1:
                    top_label = top_labels[0]; status = "single_rater"
                elif len(top_labels) == 1 and support >= min_support:
                    top_label = top_labels[0]; status = "consensus"
                else:
                    status = "unresolved"
            conf_col = f"{field}_confidence_1to5" if field in TARGETS else None
            mean_conf_top = np.nan
            mean_conf_valid = np.nan
            if conf_col and n_valid:
                confv = pd.to_numeric(valid[conf_col], errors="coerce")
                mean_conf_valid = float(confv.mean()) if confv.notna().any() else np.nan
                if top_label:
                    conft = pd.to_numeric(valid.loc[valid[field].eq(top_label), conf_col], errors="coerce")
                    mean_conf_top = float(conft.mean()) if conft.notna().any() else np.nan
            n_abstain = int(statuses.isin(["uncertain","not_assessable","not_applicable"]).sum()) if n_started else 0
            rows.append({
                "case_id": case_id, "field": field, "consensus_label": top_label,
                "consensus_status": status, "consensus_support": support,
                "n_raters_loaded": n_raters_loaded,
                "n_rater_rows": int(g_all["rater_id"].nunique()),
                "n_total_raters": n_started,
                "n_started_raters": n_started,
                "n_not_started_raters": n_not_started,
                "n_field_responses": n_responses,
                "field_response_rate_started": float(n_responses/n_started) if n_started else np.nan,
                "n_valid_raters": n_valid,
                "n_uncertain": int((statuses=="uncertain").sum()) if n_started else 0,
                "n_not_assessable": int((statuses=="not_assessable").sum()) if n_started else 0,
                "n_not_applicable": int((statuses=="not_applicable").sum()) if n_started else 0,
                "n_other": int((statuses=="other").sum()) if n_started else 0,
                "n_missing": int((statuses=="missing").sum()) if n_started else 0,
                "n_unknown": int((statuses=="unknown").sum()) if n_started else 0,
                "abstention_rate": float(n_abstain/n_started) if n_started else np.nan,
                "abstention_rate_answered": float(n_abstain/n_responses) if n_responses else np.nan,
                "human_entropy": normalized_entropy_from_counts(counts),
                "mean_confidence_top": mean_conf_top,
                "mean_confidence_valid": mean_conf_valid,
                "label_counts_json": json.dumps(counts, sort_keys=True),
            })
    return pd.DataFrame(rows)

def consensus_wide(cons_long: pd.DataFrame) -> pd.DataFrame:
    if cons_long.empty: return pd.DataFrame()
    cases = sorted(cons_long["case_id"].unique())
    cols = {"case_id": cases}
    for field in LABEL_FIELDS:
        x = cons_long[cons_long.field.eq(field)].set_index("case_id")
        cols[field] = [x["consensus_label"].get(cid, "") for cid in cases]
        for src, suffix in [
            ("consensus_status","consensus_status"),
            ("consensus_support","support"),
            ("n_raters_loaded","n_raters_loaded"),
            ("n_total_raters","n_total_raters"),
            ("n_started_raters","n_started_raters"),
            ("n_not_started_raters","n_not_started_raters"),
            ("n_field_responses","n_field_responses"),
            ("field_response_rate_started","response_rate_started"),
            ("n_valid_raters","n_valid_raters"),
            ("abstention_rate","abstention_rate"),
            ("human_entropy","human_entropy"),
            ("mean_confidence_top","mean_confidence"),
        ]:
            if src in x.columns:
                cols[f"{field}_{suffix}"] = [x[src].get(cid, np.nan) for cid in cases]
    return pd.DataFrame(cols)

def annotation_completeness(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    d=latest_annotation_state(df)
    for rater, g in d.groupby("rater_id", sort=True):
        statuses=g["case_review_status"].fillna("not_started")
        n_rows=int(g.case_id.nunique())
        n_started=int(statuses.ne("not_started").sum())
        n_complete=int(statuses.eq("complete").sum())
        n_progress=int(statuses.eq("in_progress").sum())
        n_not_started=int(statuses.eq("not_started").sum())
        base={
            "rater_id":rater,
            "n_case_rows":n_rows,
            "n_cases_present":n_started,  # backward-compatible name: now means actually started
            "n_cases_started":n_started,
            "n_cases_complete":n_complete,
            "n_cases_in_progress":n_progress,
            "n_cases_not_started":n_not_started,
            "completion_rate_of_export":float(n_complete/n_rows) if n_rows else np.nan,
            "completion_rate_among_started":float(n_complete/n_started) if n_started else np.nan,
        }
        gs=g[statuses.ne("not_started")].copy()
        for field in LABEL_FIELDS:
            sts=gs[field].map(lambda x: label_status(field,x)).value_counts() if not gs.empty else pd.Series(dtype=int)
            for st in ["valid","uncertain","not_assessable","not_applicable","other","missing","unknown"]:
                base[f"{field}_{st}"]=int(sts.get(st,0))
        rows.append(base)
    return pd.DataFrame(rows)

def pairwise_agreement(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    d=latest_annotation_state(df)
    raters=sorted(d.rater_id.unique())
    rows=[]
    for field in TARGETS:
        for a,b in combinations(raters,2):
            ga=d[d.rater_id.eq(a)][["case_id",field,"case_review_status"]].rename(columns={field:"a","case_review_status":"status_a"})
            gb=d[d.rater_id.eq(b)][["case_id",field,"case_review_status"]].rename(columns={field:"b","case_review_status":"status_b"})
            m0=ga.merge(gb,on="case_id",how="inner")
            n_export_overlap=len(m0)
            m=m0[m0.status_a.ne("not_started") & m0.status_b.ne("not_started")].copy()
            n_started=len(m)
            sa=m.a.map(lambda x:label_status(field,x)) if n_started else pd.Series(dtype=str)
            sb=m.b.map(lambda x:label_status(field,x)) if n_started else pd.Series(dtype=str)
            answered=m[(~sa.isin(["missing","unknown"])) & (~sb.isin(["missing","unknown"]))].copy() if n_started else m.copy()
            n_answered=len(answered)
            exact=float((answered.a==answered.b).mean()) if n_answered else np.nan
            mv=m[m.a.map(lambda x:is_valid_label(field,x)) & m.b.map(lambda x:is_valid_label(field,x))].copy() if n_started else m.copy()
            n_valid=len(mv)
            raw=float((mv.a==mv.b).mean()) if n_valid else np.nan
            kappa=np.nan
            if n_valid>=2:
                try:
                    kappa=float(cohen_kappa_score(mv.a,mv.b))
                except Exception:
                    kappa=np.nan
            rows.append({
                "field":field,"rater_a":a,"rater_b":b,
                "n_overlap_export_rows":n_export_overlap,
                "n_overlap_started_cases":n_started,
                "n_overlap_answered":n_answered,
                "response_exact_agreement":exact,
                "n_overlap_all":n_started,
                "overall_exact_agreement":exact,
                "n_overlap_valid":n_valid,
                "hard_label_agreement":raw,
                "cohen_kappa":kappa,
            })
    pair=pd.DataFrame(rows)
    if pair.empty:
        return pair, pd.DataFrame(columns=["field","n_pairs","total_started_overlap","total_valid_overlap","weighted_hard_label_agreement","weighted_cohen_kappa"])
    sums=[]
    for field,g in pair.groupby("field"):
        w=g.n_overlap_valid.to_numpy(float)
        def wavg(col):
            v=g[col].to_numpy(float); mask=np.isfinite(v)&(w>0)
            return float(np.average(v[mask],weights=w[mask])) if mask.any() else np.nan
        sums.append({
            "field":field,"n_pairs":len(g),
            "total_started_overlap":int(g.n_overlap_started_cases.sum()),
            "total_valid_overlap":int(g.n_overlap_valid.sum()),
            "weighted_hard_label_agreement":wavg("hard_label_agreement"),
            "weighted_cohen_kappa":wavg("cohen_kappa")
        })
    return pair,pd.DataFrame(sums)


def rater_round_statistics(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    for (rater,round_id),g in df.groupby(["rater_id","round_id"],sort=True):
        st=g["case_review_status"].fillna("not_started")
        rows.append({
            "rater_id":rater,"round_id":round_id,"n_case_rows":int(g.case_id.nunique()),
            "n_cases_started":int(st.ne("not_started").sum()),
            "n_cases_complete":int(st.eq("complete").sum()),
            "n_cases_in_progress":int(st.eq("in_progress").sum()),
            "n_cases_not_started":int(st.eq("not_started").sum()),
        })
    return pd.DataFrame(rows)


def rater_field_statistics(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    d=latest_annotation_state(df)
    for rater,g_all in d.groupby("rater_id",sort=True):
        g=g_all[g_all.case_review_status.ne("not_started")].copy()
        n_started=len(g)
        for field in LABEL_FIELDS:
            statuses=g[field].map(lambda x:label_status(field,x)) if n_started else pd.Series(dtype=str)
            responded=~statuses.isin(["missing","unknown"]) if n_started else pd.Series(dtype=bool)
            valid=statuses.eq("valid") if n_started else pd.Series(dtype=bool)
            counts=g.loc[valid,field].value_counts().to_dict() if n_started else {}
            n_resp=int(responded.sum()) if n_started else 0
            n_valid=int(valid.sum()) if n_started else 0
            conf_mean=conf_median=np.nan
            if field in TARGETS and n_valid:
                conf=pd.to_numeric(g.loc[valid,f"{field}_confidence_1to5"],errors="coerce")
                if conf.notna().any():
                    conf_mean=float(conf.mean()); conf_median=float(conf.median())
            rows.append({
                "rater_id":rater,"field":field,"n_cases_started":int(n_started),
                "n_field_responses":n_resp,
                "response_rate_started":float(n_resp/n_started) if n_started else np.nan,
                "n_valid_hard_labels":n_valid,
                "valid_label_rate_started":float(n_valid/n_started) if n_started else np.nan,
                "n_uncertain":int((statuses=="uncertain").sum()) if n_started else 0,
                "n_not_assessable":int((statuses=="not_assessable").sum()) if n_started else 0,
                "n_not_applicable":int((statuses=="not_applicable").sum()) if n_started else 0,
                "n_other":int((statuses=="other").sum()) if n_started else 0,
                "n_missing_started":int((statuses=="missing").sum()) if n_started else 0,
                "explicit_abstention_rate_started":float(statuses.isin(["uncertain","not_assessable","not_applicable"]).sum()/n_started) if n_started else np.nan,
                "valid_label_entropy":normalized_entropy_from_counts(counts),
                "mean_confidence_valid":conf_mean,"median_confidence_valid":conf_median,
                "valid_label_counts_json":json.dumps(counts,sort_keys=True),
            })
    return pd.DataFrame(rows)


def case_rater_coverage(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    d=latest_annotation_state(df)
    for _,r in d.iterrows():
        started=str(r.case_review_status)!="not_started"
        target_statuses=[label_status(t,r[t]) for t in TARGETS] if started else []
        controls=[label_status(c,r[c]) for c in CONTROLS] if started else []
        conf=[]
        if started:
            for t,st in zip(TARGETS,target_statuses):
                if st in {"valid","other"}:
                    v=pd.to_numeric(pd.Series([r[f"{t}_confidence_1to5"]]),errors="coerce").iloc[0]
                    if pd.notna(v): conf.append(float(v))
        rows.append({
            "case_id":r.case_id,"rater_id":r.rater_id,"round_id":r.round_id,
            "case_review_status":r.case_review_status,
            "started_flag":int(started),"complete_flag":int(str(r.case_review_status)=="complete"),
            "n_targets_responded":int(sum(st not in {"missing","unknown"} for st in target_statuses)),
            "n_targets_valid":int(sum(st=="valid" for st in target_statuses)),
            "n_target_abstentions":int(sum(st in {"uncertain","not_assessable","not_applicable"} for st in target_statuses)),
            "n_controls_answered":int(sum(st=="valid" for st in controls)),
            "mean_target_confidence":float(np.mean(conf)) if conf else np.nan,
        })
    return pd.DataFrame(rows)


def photo_rater_votes_long(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    d=latest_annotation_state(df)
    for _,r in d.iterrows():
        if str(r.case_review_status)=="not_started":
            continue
        for field in LABEL_FIELDS:
            conf=np.nan
            if field in TARGETS:
                conf=pd.to_numeric(pd.Series([r[f"{field}_confidence_1to5"]]),errors="coerce").iloc[0]
            rows.append({
                "case_id":r.case_id,"rater_id":r.rater_id,"round_id":r.round_id,
                "case_review_status":r.case_review_status,"field":field,"label":r[field],
                "label_status":label_status(field,r[field]),
                "confidence_1to5":conf,
            })
    return pd.DataFrame(rows)

def semantic_rule_profiles(annotation_df: pd.DataFrame, key: pd.DataFrame) -> Tuple[pd.DataFrame,pd.DataFrame]:
    d=annotation_df.merge(key[["case_id","final_rule_id","final_rule_coverage"]],on="case_id",how="inner",validate="many_to_one")
    summaries=[]; distributions=[]
    for rid, rg_all in d.groupby("final_rule_id"):
        rg=rg_all[rg_all.case_review_status.ne("not_started")].copy()
        for field in TARGETS:
            g=rg
            statuses=g[field].map(lambda x: label_status(field,x)) if len(g) else pd.Series(dtype=str)
            valid=g[statuses.eq("valid")].copy() if len(g) else g.copy()
            counts=valid[field].value_counts().to_dict() if len(g) else {}
            total=len(g); n_valid=len(valid)
            n_responses=int((~statuses.isin(["missing","unknown"])).sum()) if total else 0
            top_label=""; top_share=np.nan
            if n_valid:
                top_label=max(sorted(counts),key=lambda lab:(counts[lab],lab))
                top_share=counts[top_label]/n_valid
            conf_col=f"{field}_confidence_1to5"
            conf=pd.to_numeric(valid.loc[valid[field].eq(top_label),conf_col],errors="coerce") if top_label else pd.Series(dtype=float)
            summaries.append({
                "final_rule_id":rid,"field":field,"top_label":top_label,"top_share":top_share,
                "semantic_entropy":normalized_entropy_from_counts(counts),
                "n_annotations":int(total),"n_field_responses":n_responses,"n_valid_votes":int(n_valid),
                "n_cases":int(g.case_id.nunique()),"n_raters":int(g.rater_id.nunique()),
                "uncertain_rate":float((statuses=="uncertain").sum()/n_responses) if n_responses else np.nan,
                "not_assessable_rate":float((statuses=="not_assessable").sum()/n_responses) if n_responses else np.nan,
                "not_applicable_rate":float((statuses=="not_applicable").sum()/n_responses) if n_responses else np.nan,
                "missing_rate_started":float((statuses=="missing").mean()) if total else np.nan,
                "mean_confidence_top":float(conf.mean()) if len(conf) and conf.notna().any() else np.nan,
                "mean_rule_coverage":float(pd.to_numeric(g.final_rule_coverage,errors="coerce").mean()) if total else np.nan,
            })
            for lab,n in sorted(counts.items()):
                distributions.append({"final_rule_id":rid,"field":field,"label":lab,"n_votes":int(n),"vote_share":float(n/n_valid) if n_valid else np.nan})
    return pd.DataFrame(summaries),pd.DataFrame(distributions)

def semantic_rule_history(df: pd.DataFrame, key: pd.DataFrame) -> pd.DataFrame:
    rounds=sorted(df.round_id.unique(), key=round_rank)
    rows=[]
    for r in rounds:
        state=latest_annotation_state(df,through_round=r)
        prof,_=semantic_rule_profiles(state,key)
        if prof.empty: continue
        prof.insert(0,"through_round",r)
        rows.append(prof)
    return pd.concat(rows,ignore_index=True) if rows else pd.DataFrame()


def semantic_state_json(profiles: pd.DataFrame, history: pd.DataFrame, cons_long: pd.DataFrame) -> dict:
    state={"schema_version":SCHEMA_VERSION,"description":"Semantic evidence sidecar linked to persistent EvalOral fuzzy rule IDs. Gaussian premises are not modified by this file.","rules":{}}
    if profiles.empty: return state
    for rid, rg in profiles.groupby("final_rule_id"):
        rule={"targets":{},"history":[]}
        for _,row in rg.iterrows():
            rule["targets"][row.field]={
                "top_label":row.top_label or None,
                "top_share":None if pd.isna(row.top_share) else float(row.top_share),
                "semantic_entropy":None if pd.isna(row.semantic_entropy) else float(row.semantic_entropy),
                "n_valid_votes":int(row.n_valid_votes),"n_cases":int(row.n_cases),"n_raters":int(row.n_raters),
                "uncertain_rate":None if pd.isna(row.uncertain_rate) else float(row.uncertain_rate),
                "not_assessable_rate":None if pd.isna(row.not_assessable_rate) else float(row.not_assessable_rate),
                "not_applicable_rate":None if pd.isna(row.not_applicable_rate) else float(row.not_applicable_rate),
            }
        if not history.empty:
            h=history[history.final_rule_id.eq(rid)]
            for _,row in h.iterrows():
                rule["history"].append({"through_round":row.through_round,"field":row.field,"top_label":row.top_label or None,"top_share":None if pd.isna(row.top_share) else float(row.top_share),"semantic_entropy":None if pd.isna(row.semantic_entropy) else float(row.semantic_entropy),"n_valid_votes":int(row.n_valid_votes)})
        state["rules"][str(rid)]=rule
    state["consensus_summary"]={
        "n_cases":int(cons_long.case_id.nunique()) if not cons_long.empty else 0,
        "n_fields":int(cons_long.field.nunique()) if not cons_long.empty else 0,
    }
    return state
