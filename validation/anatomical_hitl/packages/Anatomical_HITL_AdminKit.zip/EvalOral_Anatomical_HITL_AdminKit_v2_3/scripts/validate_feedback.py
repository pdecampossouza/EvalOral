#!/usr/bin/env python3
"""Validate reviewer CSVs before scientific analysis."""
from pathlib import Path
import argparse
import pandas as pd
from feedback_utils import load_feedback, annotation_completeness, TARGETS, label_status


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('feedback_inputs',nargs='+')
    ap.add_argument('--out',default=None)
    args=ap.parse_args()
    fb,qa=load_feedback(args.feedback_inputs)
    comp=annotation_completeness(fb)
    print(f'Files/rows loaded: {len(fb)} annotation rows')
    print(f'Raters: {fb.rater_id.nunique()} -> {", ".join(sorted(fb.rater_id.unique()))}')
    print(f'Rounds: {", ".join(sorted(fb.round_id.unique()))}')
    print(f'Case rows represented in exports: {fb.case_id.nunique()}')
    print('\nCompleteness by rater:')
    if comp.empty:
        print('  no raters')
    else:
        for _,r in comp.iterrows():
            print(f"  {r.rater_id}: started={int(r.n_cases_started)}, complete={int(r.n_cases_complete)}, in_progress={int(r.n_cases_in_progress)}, not_started={int(r.n_cases_not_started)}")
    print('\nNon-label states by target:')
    for t in TARGETS:
        started=fb[fb.case_review_status.ne('not_started')]
        s=started[t].map(lambda x: label_status(t,x)).value_counts()
        print(f"  {t}: uncertain={int(s.get('uncertain',0))}, not_assessable={int(s.get('not_assessable',0))}, not_applicable={int(s.get('not_applicable',0))}, missing={int(s.get('missing',0))}")
    if not qa.empty:
        print('\nQA notes:')
        for _,r in qa.iterrows(): print(f"  [{r.severity}] {r.issue}: {r.detail}")
    if args.out:
        out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
        comp.to_csv(out/'rater_completeness.csv',index=False)
        qa.to_csv(out/'ingestion_qa.csv',index=False)

if __name__=='__main__': main()
