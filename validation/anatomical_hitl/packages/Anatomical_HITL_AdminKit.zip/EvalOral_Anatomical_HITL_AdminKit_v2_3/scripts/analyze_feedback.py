#!/usr/bin/env python3
"""Analyze EvalOral anatomical human-in-the-loop feedback v2.

Accepts one or more reviewer CSV files, a directory containing CSV files, or
glob patterns. Individual rater evidence is preserved. Consensus is derived as
an analysis layer and is then used for volunteer-held-out semantic evaluation.

This research utility does not provide clinical diagnosis.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import LabelEncoder

from evolving_nf_evaloral_reference import EvolvingNeuroFuzzyEvalOral
from feedback_utils import (
    TARGETS, CONTROLS, LABEL_FIELDS, FEATURES, VALID_LABELS,
    load_feedback, latest_annotation_state, annotation_completeness,
    build_consensus_long, consensus_wide, pairwise_agreement,
    semantic_rule_profiles, semantic_rule_history, semantic_state_json,
    rater_round_statistics, rater_field_statistics, case_rater_coverage,
    photo_rater_votes_long, label_status,
)


def eval_target(data: pd.DataFrame, target: str, subset: str, mask=None):
    d=data.copy()
    if mask is not None:
        d=d[mask.reindex(d.index,fill_value=False)]
    d=d[d[target].fillna('').isin(VALID_LABELS[target])].copy()
    d=d.dropna(subset=FEATURES+[target,'volunteer_id'])
    if len(d)<12 or d[target].nunique()<2 or d.volunteer_id.nunique()<3:
        return None,None

    le=LabelEncoder(); y=le.fit_transform(d[target].astype(str))
    X=d[FEATURES].to_numpy(float); groups=d.volunteer_id.to_numpy()
    logo=LeaveOneGroupOut(); rows=[]
    for fold,(tr,te) in enumerate(logo.split(X,y,groups),1):
        if np.unique(y[tr]).size<2:
            continue
        lr=LogisticRegression(max_iter=3000,class_weight='balanced')
        lr.fit(X[tr],y[tr]); plr=lr.predict(X[te])

        nf=EvolvingNeuroFuzzyEvalOral(
            n_features=4,n_classes=len(le.classes_),alpha_add=0.4,tau_merge=1.1,
            sigma_init=1.0,activation_mode='coverage_gated_unim',
            label_conflict_policy='new_rule',label_conflict_min_confidence=0.60,
            feature_names=FEATURES,class_names=list(le.classes_)
        )
        order=np.argsort(d.iloc[tr]['case_id'].to_numpy())
        nf.partial_fit(X[tr][order],y[tr][order]); pnf=nf.predict(X[te])
        for j,idx in enumerate(te):
            rows.append({
                'subset':subset,'target':target,'fold':fold,
                'case_id':d.iloc[idx].case_id,'volunteer_id':groups[idx],
                'true_label':le.inverse_transform([y[idx]])[0],
                'logreg_pred':le.inverse_transform([plr[j]])[0],
                'nf_pred':le.inverse_transform([pnf[j]])[0],
            })
    pred=pd.DataFrame(rows)
    if pred.empty:
        return None,None
    summary=[]
    for model,col in [('logistic_regression','logreg_pred'),('evolving_nf','nf_pred')]:
        summary.append({
            'subset':subset,'target':target,'model':model,'n_labeled':len(d),
            'n_classes':d[target].nunique(),'n_volunteers':d.volunteer_id.nunique(),
            'accuracy':accuracy_score(pred.true_label,pred[col]),
            'macro_f1':f1_score(pred.true_label,pred[col],average='macro',zero_division=0),
            'classes':'|'.join(le.classes_),
        })
    return pd.DataFrame(summary),pred


def label_distributions_raw(df):
    rows=[]
    for (rater,round_id),g in df.groupby(['rater_id','round_id'],sort=True):
        for field in LABEL_FIELDS:
            vc=g[field].fillna('').value_counts(dropna=False)
            for lab,n in vc.items():
                rows.append({'rater_id':rater,'round_id':round_id,'field':field,'label':lab,'status':label_status(field,lab),'n':int(n)})
    return pd.DataFrame(rows)


def label_distributions_consensus(cons_long):
    rows=[]
    for field,g in cons_long.groupby('field'):
        vc=g.consensus_label.fillna('').value_counts(dropna=False)
        for lab,n in vc.items():
            rows.append({'field':field,'consensus_label':lab,'n':int(n)})
    return pd.DataFrame(rows)


def disagreement_table(cons_long):
    d=cons_long[cons_long.field.isin(TARGETS)].copy()
    d['disagreement_score']=d['human_entropy'].fillna(0.0)+d['abstention_rate'].fillna(0.0)
    return d.sort_values(['disagreement_score','human_entropy','abstention_rate'],ascending=False)




def label_distributions_current(df):
    votes=photo_rater_votes_long(df)
    if votes.empty:
        return pd.DataFrame(columns=['rater_id','field','label','status','n'])
    x=votes.groupby(['rater_id','field','label','label_status'],dropna=False).size().reset_index(name='n')
    return x.rename(columns={'label_status':'status'})


def build_photo_summary(latest, cons_long, key):
    coverage=case_rater_coverage(latest)
    if coverage.empty:
        return pd.DataFrame()
    rows=[]
    n_loaded=int(latest.rater_id.nunique())
    for case_id,g in coverage.groupby('case_id',sort=True):
        started=g.started_flag.eq(1)
        rows.append({
            'case_id':case_id,'n_raters_loaded':n_loaded,
            'n_raters_started':int(started.sum()),
            'n_raters_complete':int(g.complete_flag.sum()),
            'n_raters_in_progress':int((g.case_review_status=='in_progress').sum()),
            'n_raters_not_started':int((g.case_review_status=='not_started').sum()),
            'review_coverage_rate':float(started.sum()/n_loaded) if n_loaded else np.nan,
            'mean_target_confidence_across_raters':float(g.loc[started,'mean_target_confidence'].mean()) if started.any() else np.nan,
        })
    out=pd.DataFrame(rows)
    tg=cons_long[cons_long.field.isin(TARGETS)].copy()
    if not tg.empty:
        agg=[]
        for case_id,g in tg.groupby('case_id',sort=True):
            resolved=g.consensus_status.isin(['single_rater','consensus'])
            supports=pd.to_numeric(g.loc[resolved,'consensus_support'],errors='coerce')
            agg.append({
                'case_id':case_id,
                'n_targets_resolved':int(resolved.sum()),
                'n_targets_consensus':int(g.consensus_status.eq('consensus').sum()),
                'n_targets_single_rater':int(g.consensus_status.eq('single_rater').sum()),
                'n_targets_unresolved':int(g.consensus_status.eq('unresolved').sum()),
                'n_targets_no_valid_label':int(g.consensus_status.eq('no_valid_label').sum()),
                'mean_resolved_support':float(supports.mean()) if supports.notna().any() else np.nan,
                'mean_human_entropy':float(pd.to_numeric(g.human_entropy,errors='coerce').mean()),
                'mean_abstention_rate':float(pd.to_numeric(g.abstention_rate,errors='coerce').mean()),
            })
        out=out.merge(pd.DataFrame(agg),on='case_id',how='left',validate='one_to_one')
    key_cols=[c for c in ['case_id','volunteer_id','final_rule_id','final_rule_coverage','cluster_coarse','cluster_fine','selection_reason'] if c in key.columns]
    out=out.merge(key[key_cols],on='case_id',how='left',validate='one_to_one')
    cw=consensus_wide(cons_long)
    if not cw.empty:
        keep=['case_id']
        for t in TARGETS:
            for c in [t,f'{t}_consensus_status',f'{t}_support',f'{t}_n_valid_raters',f'{t}_human_entropy',f'{t}_mean_confidence']:
                if c in cw.columns: keep.append(c)
        out=out.merge(cw[keep],on='case_id',how='left',validate='one_to_one')
    return out


def write_statistics_report(path, manifest, rater_comp, rater_field, photo_summary, agreement):
    def table(df,cols=None,max_rows=200):
        if df is None or df.empty:
            return '<p><em>No data available.</em></p>'
        x=df.copy()
        if cols is not None:
            x=x[[c for c in cols if c in x.columns]]
        return x.head(max_rows).to_html(index=False,border=0,classes='data',na_rep='')
    rc_cols=['rater_id','n_case_rows','n_cases_started','n_cases_complete','n_cases_in_progress','n_cases_not_started','completion_rate_of_export','completion_rate_among_started']
    agr_cols=['field','n_pairs','total_started_overlap','total_valid_overlap','weighted_hard_label_agreement','weighted_cohen_kappa']
    photo_cols=['case_id','n_raters_loaded','n_raters_started','n_raters_complete','review_coverage_rate','n_targets_resolved','n_targets_unresolved','mean_human_entropy','mean_abstention_rate','final_rule_id','final_rule_coverage']
    html=(
        '<!doctype html><html><head><meta charset="utf-8"><title>EvalOral review statistics</title>'
        '<style>body{font-family:Arial,sans-serif;margin:28px;color:#1b1d22}h1,h2{margin-top:1.4em}'
        '.cards{display:flex;gap:12px;flex-wrap:wrap}.card{border:1px solid #d9dde5;border-radius:10px;padding:12px 16px;background:#f8f9fb}'
        'table.data{border-collapse:collapse;width:100%;font-size:12px}table.data th,table.data td{border-bottom:1px solid #e6e8ec;padding:6px;text-align:left}'
        'table.data th{background:#f2f4f7;position:sticky;top:0}.note{background:#fff6df;padding:10px;border-radius:8px}</style></head><body>'
        '<h1>EvalOral — Multi-rater review statistics</h1>'
        '<p class="note">Partial review is supported. <strong>not_started</strong> is absence of review and is not counted as <strong>uncertain</strong> or as pairwise agreement.</p>'
        f'<div class="cards"><div class="card"><strong>Raters</strong><br>{manifest.get("n_raters",0)}</div>'
        f'<div class="card"><strong>Cases started by ≥1 rater</strong><br>{manifest.get("n_cases_started_any",0)}</div>'
        f'<div class="card"><strong>Current rater-case rows</strong><br>{manifest.get("n_current_rater_case_rows",0)}</div></div>'
        '<h2>Completion by reviewer</h2>'+table(rater_comp,rc_cols)+
        '<h2>Agreement by anatomical concept</h2>'+table(agreement,agr_cols)+
        '<h2>Classification statistics by reviewer and field</h2>'+table(rater_field,max_rows=500)+
        '<h2>Statistics by photograph</h2>'+table(photo_summary,photo_cols,max_rows=200)+
        '</body></html>'
    )
    Path(path).write_text(html,encoding='utf-8')

def semantic_evolution_events(history: pd.DataFrame) -> pd.DataFrame:
    """Summarize how each rule/field semantic state changes across rounds."""
    if history.empty:
        return pd.DataFrame(columns=['final_rule_id','field','from_round','to_round','from_label','to_label','label_changed','delta_top_share','delta_entropy','delta_valid_votes'])
    rows=[]
    h=history.copy()
    # preserve history row order produced by semantic_rule_history (round order)
    for (rid,field),g in h.groupby(['final_rule_id','field'],sort=False):
        g=g.reset_index(drop=True)
        for i in range(1,len(g)):
            a,b=g.iloc[i-1],g.iloc[i]
            rows.append({
                'final_rule_id':rid,'field':field,'from_round':a.through_round,'to_round':b.through_round,
                'from_label':a.top_label,'to_label':b.top_label,'label_changed':bool(str(a.top_label)!=str(b.top_label)),
                'delta_top_share':(b.top_share-a.top_share) if pd.notna(a.top_share) and pd.notna(b.top_share) else np.nan,
                'delta_entropy':(b.semantic_entropy-a.semantic_entropy) if pd.notna(a.semantic_entropy) and pd.notna(b.semantic_entropy) else np.nan,
                'delta_valid_votes':int(b.n_valid_votes-a.n_valid_votes),
            })
    cols=['final_rule_id','field','from_round','to_round','from_label','to_label','label_changed','delta_top_share','delta_entropy','delta_valid_votes']
    return pd.DataFrame(rows,columns=cols)

def main():
    ap=argparse.ArgumentParser(description='Analyze one or more EvalOral reviewer CSV files.')
    ap.add_argument('feedback_inputs',nargs='+',help='CSV file(s), directory, or glob pattern(s)')
    ap.add_argument('--out',default=None)
    ap.add_argument('--consensus-min-support',type=float,default=0.60)
    args=ap.parse_args()

    root=Path(__file__).resolve().parents[1]
    out=Path(args.out) if args.out else root/'analysis'/'completed_feedback_analysis_v2'
    out.mkdir(parents=True,exist_ok=True)

    fb,qa=load_feedback(args.feedback_inputs)
    key=pd.read_csv(root/'keys'/'anatomical_feedback_round1_admin_key.csv')
    unknown_cases=sorted(set(fb.case_id)-set(key.case_id))
    if unknown_cases:
        raise ValueError('Feedback contains case_id values not present in admin key: '+', '.join(unknown_cases[:20]))

    latest=latest_annotation_state(fb)
    cons_long=build_consensus_long(fb,min_support=args.consensus_min_support)
    cons_wide=consensus_wide(cons_long)

    # Main outputs: raw evidence, QA, completeness, agreement, consensus.
    fb.to_csv(out/'raw_annotations_normalized.csv',index=False)
    latest.to_csv(out/'current_annotation_state_by_rater.csv',index=False)
    qa.to_csv(out/'ingestion_qa.csv',index=False)
    rater_comp=annotation_completeness(fb)
    rater_round=rater_round_statistics(fb)
    rater_field=rater_field_statistics(fb)
    case_coverage=case_rater_coverage(fb)
    votes_long=photo_rater_votes_long(fb)
    rater_comp.to_csv(out/'rater_completeness.csv',index=False)
    rater_round.to_csv(out/'rater_round_statistics.csv',index=False)
    rater_field.to_csv(out/'rater_classification_statistics.csv',index=False)
    label_distributions_raw(fb).to_csv(out/'rater_label_distribution_all_rounds.csv',index=False)
    label_distributions_current(fb).to_csv(out/'rater_label_distribution.csv',index=False)
    case_coverage.to_csv(out/'photo_rater_coverage.csv',index=False)
    votes_long.to_csv(out/'photo_rater_votes_long.csv',index=False)
    cons_long.to_csv(out/'consensus_long.csv',index=False)
    cons_wide.to_csv(out/'consensus_wide.csv',index=False)
    label_distributions_consensus(cons_long).to_csv(out/'consensus_label_distribution.csv',index=False)
    disagreement_table(cons_long).to_csv(out/'human_disagreement_cases.csv',index=False)
    signal_cols=['case_id','volunteer_id','final_rule_id','final_rule_coverage','cluster_coarse','cluster_fine','selection_reason']
    photo_classification=cons_long.merge(key[signal_cols],on='case_id',how='left',validate='many_to_one')
    photo_classification.to_csv(out/'case_rule_human_signals.csv',index=False)
    photo_classification.to_csv(out/'photo_classification_statistics.csv',index=False)
    photo_summary=build_photo_summary(latest,cons_long,key)
    photo_summary.to_csv(out/'photo_summary_statistics.csv',index=False)

    pair,agree_summary=pairwise_agreement(fb)
    pair.to_csv(out/'pairwise_rater_agreement.csv',index=False)
    agree_summary.to_csv(out/'inter_rater_summary.csv',index=False)

    # Rule-linked semantic evidence. Individual expert votes are retained here.
    profiles,dist=semantic_rule_profiles(latest,key)
    history=semantic_rule_history(fb,key)
    profiles.to_csv(out/'semantic_rule_profiles.csv',index=False)
    dist.to_csv(out/'semantic_rule_label_distribution.csv',index=False)
    history.to_csv(out/'semantic_rule_history.csv',index=False)
    semantic_evolution_events(history).to_csv(out/'semantic_rule_evolution_events.csv',index=False)
    with (out/'rule_semantic_state.json').open('w',encoding='utf-8') as f:
        json.dump(semantic_state_json(profiles,history,cons_long),f,indent=2,ensure_ascii=False)

    # Consensus is one row per image, therefore safe for held-out evaluation.
    data=key.merge(cons_wide,on='case_id',how='inner',validate='one_to_one')
    keep_cols=['case_id','volunteer_id','final_rule_id','final_rule_coverage']+FEATURES
    for field in LABEL_FIELDS:
        if field in data.columns: keep_cols.append(field)
        for suffix in ['consensus_status','support','n_raters_loaded','n_total_raters','n_started_raters','n_not_started_raters','n_field_responses','response_rate_started','n_valid_raters','abstention_rate','human_entropy','mean_confidence']:
            c=f'{field}_{suffix}'
            if c in data.columns: keep_cols.append(c)
    data[keep_cols].to_csv(out/'merged_consensus_with_features.csv',index=False)

    all_s=[]; all_p=[]
    for target in TARGETS:
        # Primary: any resolved single-rater or multi-rater consensus hard label.
        s,p=eval_target(data,target,'all_resolved')
        if s is not None: all_s.append(s); all_p.append(p)

        # Sensitivity: only images whose quality consensus is adequate.
        if 'image_quality' in data.columns:
            mask=data.image_quality.eq('adequate')
            s,p=eval_target(data,target,'adequate_images_only',mask)
            if s is not None: all_s.append(s); all_p.append(p)

        # Sensitivity: when multiple raters exist, require at least 2 valid raters
        # and >= 2/3 support. With a single rater this subset is intentionally absent.
        ncol=f'{target}_n_valid_raters'; scol=f'{target}_support'
        if ncol in data.columns and pd.to_numeric(data[ncol],errors='coerce').max()>=2:
            mask=(pd.to_numeric(data[ncol],errors='coerce')>=2) & (pd.to_numeric(data[scol],errors='coerce')>=2/3)
            s,p=eval_target(data,target,'multi_rater_high_consensus',mask)
            if s is not None: all_s.append(s); all_p.append(p)

    if all_s:
        pd.concat(all_s,ignore_index=True).to_csv(out/'heldout_volunteer_metrics.csv',index=False)
    else:
        pd.DataFrame(columns=['subset','target','model','n_labeled','n_classes','n_volunteers','accuracy','macro_f1','classes']).to_csv(out/'heldout_volunteer_metrics.csv',index=False)
    if all_p:
        pd.concat(all_p,ignore_index=True).to_csv(out/'heldout_volunteer_predictions.csv',index=False)
    else:
        pd.DataFrame(columns=['subset','target','fold','case_id','volunteer_id','true_label','logreg_pred','nf_pred']).to_csv(out/'heldout_volunteer_predictions.csv',index=False)

    manifest={
        'schema_version':'2.2',
        'n_input_rows':int(len(fb)),
        'n_current_rater_case_rows':int(len(latest)),
        'n_raters':int(fb.rater_id.nunique()),
        'raters':sorted(fb.rater_id.unique().tolist()),
        'rounds':sorted(fb.round_id.unique().tolist()),
        'n_cases_in_exports':int(fb.case_id.nunique()),
        'n_cases_started_any':int(latest.loc[latest.case_review_status.ne('not_started'),'case_id'].nunique()),
        'n_cases_complete_any':int(latest.loc[latest.case_review_status.eq('complete'),'case_id'].nunique()),
        'consensus_min_support':float(args.consensus_min_support),
        'important_note':'rule_semantic_state.json updates semantic evidence linked to persistent rule IDs; it does not mutate Gaussian rule premises.',
    }
    with (out/'analysis_manifest.json').open('w',encoding='utf-8') as f:
        json.dump(manifest,f,indent=2,ensure_ascii=False)
    print(f"Analysis written to {out}")
    write_statistics_report(out/'review_statistics_report.html',manifest,rater_comp,rater_field,photo_summary,agree_summary)
    print(f"Raters: {manifest['n_raters']} | cases started by >=1 rater: {manifest['n_cases_started_any']} | rounds: {', '.join(manifest['rounds'])}")

if __name__=='__main__':
    main()
