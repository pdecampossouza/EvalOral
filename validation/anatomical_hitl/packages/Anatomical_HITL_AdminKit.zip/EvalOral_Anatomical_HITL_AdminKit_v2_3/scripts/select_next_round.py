#!/usr/bin/env python3
"""Select new and re-review cases for the next EvalOral anatomical round.

New-case selection uses semantic classifier uncertainty + fuzzy novelty.
Already-reviewed cases are scored separately for human disagreement/abstention.
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder

from feedback_utils import (
    TARGETS, FEATURES, VALID_LABELS, load_feedback,
    build_consensus_long, consensus_wide,
)


def entropy(P):
    P=np.clip(P,1e-12,1.0)
    H=-(P*np.log(P)).sum(axis=1)
    return H/np.log(P.shape[1]) if P.shape[1]>1 else np.zeros(len(P))


def build_rereview(cons_long,key,max_n=12,n_raters_loaded=None):
    d=cons_long[cons_long.field.isin(TARGETS)].copy()
    if d.empty:
        return pd.DataFrame()
    d['low_support']=1.0-pd.to_numeric(d.consensus_support,errors='coerce').fillna(0.0)
    d.loc[d.consensus_status.eq('single_rater'),'low_support']=0.0
    d['unresolved_flag']=d.consensus_status.eq('unresolved').astype(float)
    rows=[]
    for case_id,g in d.groupby('case_id'):
        human_entropy=float(g.human_entropy.fillna(0).mean())
        abstention=float(g.abstention_rate.fillna(0).mean())
        low_support=float(g.low_support.fillna(0).mean())
        unresolved=float(g.unresolved_flag.mean())
        n_started=int(pd.to_numeric(g.n_total_raters,errors='coerce').max()) if len(g) else 0
        total_loaded=int(n_raters_loaded or pd.to_numeric(g.get('n_raters_loaded',pd.Series([n_started])),errors='coerce').max() or n_started)
        coverage_gap=(1.0-n_started/total_loaded) if total_loaded else 0.0
        score=0.30*human_entropy+0.20*low_support+0.15*abstention+0.15*unresolved+0.20*coverage_gap
        reasons=[]
        if coverage_gap>0: reasons.append('incomplete_rater_coverage')
        if human_entropy>=0.25: reasons.append('expert_disagreement')
        if unresolved>0: reasons.append('unresolved_consensus')
        if abstention>=0.25: reasons.append('high_abstention')
        if not reasons and n_started<2:
            reasons.append('single_rater_second_opinion')
        if not reasons and score>0:
            reasons.append('low_consensus_signal')
        if not reasons:
            reasons.append('low_priority_second_opinion')
        rows.append({'case_id':case_id,'rereview_score':score,'n_raters_started':n_started,'n_raters_loaded':total_loaded,'rater_coverage_gap':coverage_gap,'mean_human_entropy':human_entropy,'mean_low_consensus':low_support,'mean_abstention_rate':abstention,'unresolved_fraction':unresolved,'rereview_reason':'|'.join(reasons)})
    out=pd.DataFrame(rows).merge(key,on='case_id',how='left',validate='one_to_one')
    return out.sort_values('rereview_score',ascending=False).head(max_n)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('feedback_inputs',nargs='+',help='CSV file(s), directory, or glob pattern(s)')
    ap.add_argument('--n',type=int,default=24,help='Number of new images for next round')
    ap.add_argument('--max-rereview',type=int,default=12,help='Maximum already-reviewed cases to flag')
    ap.add_argument('--out',default=None)
    ap.add_argument('--consensus-min-support',type=float,default=0.60)
    args=ap.parse_args()

    root=Path(__file__).resolve().parents[1]
    out=Path(args.out) if args.out else root/'analysis'/'round2_selection_v2'
    out.mkdir(parents=True,exist_ok=True)

    key=pd.read_csv(root/'keys'/'anatomical_feedback_round1_admin_key.csv')
    fb,_=load_feedback(args.feedback_inputs)
    cons_long=build_consensus_long(fb,min_support=args.consensus_min_support)
    cons=consensus_wide(cons_long)
    train=key.merge(cons,on='case_id',how='inner',validate='one_to_one')

    pool=pd.read_csv(root/'keys'/'full_view121_pool.csv')
    used=set(key.image_id)
    pool=pool[~pool.image_id.isin(used)].copy().reset_index(drop=True)
    scores=[]
    trained_targets=[]
    for t in TARGETS:
        d=train[train[t].fillna('').isin(VALID_LABELS[t])].dropna(subset=FEATURES+[t])
        if len(d)<10 or d[t].nunique()<2:
            continue
        le=LabelEncoder(); y=le.fit_transform(d[t].astype(str)); X=d[FEATURES].to_numpy(float)
        model=LogisticRegression(max_iter=3000,class_weight='balanced')
        model.fit(X,y)
        P=model.predict_proba(pool[FEATURES].to_numpy(float))
        u=entropy(P)
        pool[f'uncertainty_{t}']=u
        scores.append(u); trained_targets.append(t)

    pool['semantic_uncertainty']=np.mean(np.vstack(scores),axis=0) if scores else 0.0
    pool['fuzzy_novelty']=1.0-pd.to_numeric(pool.final_rule_coverage,errors='coerce').clip(0,1)
    pool['active_score']=0.7*pool.semantic_uncertainty+0.3*pool.fuzzy_novelty
    pool['trained_semantic_targets']='|'.join(trained_targets)

    # Greedy diversity limits retained from the original pilot selector.
    chosen=[]; volunteer_counts={}; cluster_counts={}
    for _,r in pool.sort_values('active_score',ascending=False).iterrows():
        vid=r.volunteer_id; cl=r.cluster_fine
        if volunteer_counts.get(vid,0)>=3: continue
        if cluster_counts.get(cl,0)>=5: continue
        chosen.append(r)
        volunteer_counts[vid]=volunteer_counts.get(vid,0)+1
        cluster_counts[cl]=cluster_counts.get(cl,0)+1
        if len(chosen)>=args.n: break
    new=pd.DataFrame(chosen)
    new.to_csv(out/'round2_new_candidates.csv',index=False)
    new.to_csv(out/'round2_candidates.csv',index=False)  # compatibility name

    rereview=build_rereview(cons_long,key,max_n=args.max_rereview,n_raters_loaded=int(fb.rater_id.nunique()))
    rereview.to_csv(out/'rereview_candidates.csv',index=False)

    print(f'Selected {len(new)} new cases -> {out / "round2_new_candidates.csv"}')
    print(f'Flagged {len(rereview)} re-review cases -> {out / "rereview_candidates.csv"}')
    if not trained_targets:
        print('WARNING: no semantic target had enough resolved labels for uncertainty modeling; new-case ranking used fuzzy novelty only.')

if __name__=='__main__':
    main()
