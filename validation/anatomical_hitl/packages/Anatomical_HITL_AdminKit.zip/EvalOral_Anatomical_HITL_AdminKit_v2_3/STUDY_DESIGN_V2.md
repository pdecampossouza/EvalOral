# Study design v2 — semantic evolution before structural evolution

## Experimental object

The study treats a persistent fuzzy rule as having two separable states:

```text
geometric state
  center, sigma, coverage, PCA region

semantic state
  expert-supported distributions over anatomy
```

Round 1 updates the semantic state while leaving the geometric state unchanged for the primary semantic-calibration analysis.

## Why this separation matters

If anatomical meaning emerges on held-out volunteers without refitting Gaussian premises from the same labels, the result supports the hypothesis that the pre-existing visual geometry contains reusable anatomical structure.

If expert evidence remains persistently mixed within a high-coverage rule, that conflict becomes a candidate trigger for a later structural phase:

```text
semantic conflict
    -> rule split
    -> child rule
    -> new rule
    -> premise adaptation
```

Those structural actions should be evaluated as a subsequent experiment rather than silently mixed into Round 1.

## Human evidence is not collapsed at ingestion

Multiple expert responses are retained individually. Consensus, agreement, entropy, and abstention rates are derived outputs. This makes it possible to compare:

- model uncertainty;
- expert disagreement;
- explicit expert abstention;
- fuzzy novelty;
- cross-volunteer transfer.


## Unequal reviewer completion

The design permits unequal reviewer coverage. Statistical summaries report both case coverage and field-level response coverage. Reliability statistics are computed only on overlapping reviewed cases, preventing an exported-but-empty row from being counted as agreement or disagreement.
