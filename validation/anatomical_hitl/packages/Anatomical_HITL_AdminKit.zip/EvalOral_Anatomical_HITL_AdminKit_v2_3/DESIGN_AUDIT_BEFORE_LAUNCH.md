# Design audit before sending Round 1 to experts

## Important property of the current 48-image selection

The hidden administrative key confirms that all 48 Round 1 cases come from:

```text
source_module = permanent_dentition_DAI
```

The current 121-image active-learning pool is also the DAI view-task pool. Therefore **dentition does not have designed class diversity in the current sampling universe**.

Consequences:

- `dentition` can be collected as a secondary descriptive/context field;
- the analysis code will automatically skip a dentition classifier if fewer than two usable classes are present;
- dentition should **not** be advertised as a primary Round 1 discriminative endpoint with the current 48 images;
- if the new paper intends to study learning of `permanent / deciduous / mixed` as a real semantic target, the sampling frame must be expanded beyond the DAI pool before that claim is tested.

This does **not** invalidate the main hierarchy:

```text
image -> view -> arch -> side -> region -> tooth group -> future tooth instance
```

The current 48 images were deliberately selected across 10 photographed volunteers and 15 fuzzy rules, with 24 high-coverage representative cases and 24 lower-coverage/boundary cases. That selection remains suitable for a first semantic-acquisition pilot over view, arch, side, region, and tooth group.

## Multi-rater effective sample size

Multiple experts improve reliability and permit agreement analysis, but three ratings of the same photograph are **not three independent images**. Predictive/generalization analyses therefore use a derived one-row-per-case semantic state and keep `volunteer_id` as the held-out grouping variable. Raw rater rows are never treated as independent training samples in the main leave-one-volunteer-out evaluation.

## Recommended launch interpretation

Treat Round 1 as a multi-expert semantic-acquisition pilot with five primary anatomical concepts and dentition as secondary context. A broader corpus can be introduced in a later round if dentition or tooth-level identity becomes a primary endpoint.
