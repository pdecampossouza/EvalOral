# EvalOral Admin Dashboard v2.3

1. Abra `admin_dashboard.html` no navegador.
2. Arraste para a caixa um ou vários CSVs devolvidos pelos avaliadores.
3. Use as abas **Visão geral**, **Avaliadores**, **Fotografias**, **Concordância** e **QA dos dados**.
4. Em **Fotografias**, clique em um `AN-xxx` para ver a fotografia, todos os votos individuais, consenso, suporte, entropia humana e os metadados ocultos da regra fuzzy.
5. Coletas parciais são aceitas: `not_started` continua sendo ausência de revisão, não `uncertain`.
6. O dashboard serve para inspeção rápida. Para resultados científicos, rode depois `scripts/validate_feedback.py` e `scripts/analyze_feedback.py`.

Nenhum CSV é enviado para a internet: o navegador lê os arquivos localmente.
