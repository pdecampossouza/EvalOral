# Data dictionary — EvalOral Anatomical HITL v2

## Annotation identity

- `study_id`: fixed study identifier.
- `schema_version`: reviewer export schema; v2.2 uses `2.2`; the Admin remains backward-compatible with v2.0 exports.
- `round_id`: feedback round, e.g. `R1`, `R2`.
- `rater_id`: pseudonymous expert code, e.g. `R01`.
- `annotation_id`: convenience ID combining round, rater and case.
- `case_id`: blinded image identifier.
- `case_review_status`: `not_started`, `in_progress`, or `complete`. This distinguishes an unreviewed photograph from an explicit expert abstention.

## Anatomical targets

- `view`
- `arch`
- `side`
- `region`
- `tooth_group`
- `dentition`

Each target has `<target>_confidence_1to5` when a substantive anatomical label is selected.

## Explicit non-label states

- `uncertain`: observable concept remains ambiguous.
- `not_assessable`: concept applies but visual information is insufficient.
- `not_applicable`: concept genuinely does not apply; expected to be rare.

These are stored and analyzed separately. They are not silently converted into hard labels.

## Case-level controls

- `image_quality`: `adequate`, `limited`, `unusable`.
- `instrument_present`: `no`, `yes_minor`, `yes_major`.
- `notes`: optional free text.
- `case_started_at_utc`, `case_last_modified_utc`: browser timestamps used for audit/resume and duplicate resolution.

## Hidden administrative fields

The admin key links `case_id` to fields such as:

- `volunteer_id`;
- `final_rule_id`;
- `final_rule_coverage`;
- `cluster_coarse`, `cluster_fine`;
- `PC1–PC4`;
- source/released metadata.

These must remain hidden from the reviewer during annotation.


## Partial reviewer coverage

A reviewer CSV may contain all 48 case rows while only a subset was actually reviewed. The Admin Kit recomputes `case_review_status` from annotation content, so an empty exported row is treated as `not_started`, not as `uncertain` and not as pairwise agreement. Agreement denominators use only cases actually started by both reviewers; hard-label kappa uses only overlapping valid hard labels.

## Reviewer- and photograph-level statistics

- `rater_completeness.csv`: started, complete, in-progress, and not-started counts by reviewer.
- `rater_classification_statistics.csv`: response, valid-label, abstention, entropy, and confidence statistics by reviewer × field.
- `rater_label_distribution.csv`: current label counts by reviewer × field × label.
- `photo_rater_coverage.csv`: one row per photograph × reviewer with review/completion coverage.
- `photo_rater_votes_long.csv`: individual reviewer votes by photograph × field.
- `photo_classification_statistics.csv`: consensus/support/entropy statistics by photograph × field.
- `photo_summary_statistics.csv`: one-row-per-photograph summary of reviewer coverage and semantic resolution.
- `review_statistics_report.html`: compact browser-readable overview.
