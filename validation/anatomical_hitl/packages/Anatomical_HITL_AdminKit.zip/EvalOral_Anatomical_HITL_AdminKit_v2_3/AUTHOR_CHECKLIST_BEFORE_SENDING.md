# Author checklist before sending the reviewer kit

- [ ] Read `DESIGN_AUDIT_BEFORE_LAUNCH.md`.
- [ ] Decide whether dentition is secondary context (recommended for the current 48-image DAI set) or whether the sampling frame must be broadened first.
- [ ] Assign pseudonymous reviewer codes such as `R01`, `R02`, `R03`.
- [ ] Send **only** `EvalOral_Anatomical_HITL_Round1_ReviewerKit_v2.zip` to reviewers.
- [ ] Do not send this Admin Kit, PCA explorer, rule IDs, coverage, clusters, released labels, or selection reasons.
- [ ] Ask reviewers to work independently and not reconcile answers with one another before submission.
- [ ] Ask each reviewer to confirm `completos: 48/48` before final export.
- [ ] Keep each returned CSV unchanged and place all files in `feedbacks/`.
- [ ] Run `python scripts/validate_feedback.py feedbacks/` before any scientific analysis.
- [ ] Run `python scripts/analyze_feedback.py feedbacks/` only after validation.
- [ ] Keep all `analysis/SOFTWARE_QA_v2/` files separate from real study results.
