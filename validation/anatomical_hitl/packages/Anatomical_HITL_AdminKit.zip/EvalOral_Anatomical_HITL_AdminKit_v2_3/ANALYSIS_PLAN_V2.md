# Analysis plan v2 — proposed new paper

This file defines the intended analysis before real expert labels are inspected. It is a planning document, not a claim that all endpoints are already validated.

## Primary anatomical hierarchy

```text
view -> arch -> patient side -> region -> dominant tooth group
```

`dentition` is collected as secondary context in the current Round 1 because the present 48-image and 121-image DAI sampling universe is sourced from the permanent-dentition DAI module.

## Unit of analysis

- **Image-level semantic learning:** one resolved semantic state per blinded `case_id`.
- **Generalization grouping:** `volunteer_id` is held out so images from the same photographed volunteer do not leak across train/test.
- **Human reliability:** individual `rater_id` responses are retained for agreement analysis but are not treated as independent images.
- **Rule-level evolution:** expert evidence is linked to persistent `final_rule_id` values.

## Proposed research questions

### RQ1 — Human reproducibility

Can independent dental experts assign the coarse anatomical concepts consistently, and which concepts generate the most `uncertain`, `not_assessable`, or unresolved responses?

Primary outputs:

- pairwise hard-label agreement;
- Cohen kappa;
- consensus support;
- human semantic entropy;
- explicit abstention rates.

### RQ2 — Transfer of anatomical semantics

Can semantic labels learned from expert-reviewed images transfer to images from held-out photographed volunteers?

Primary evaluation:

- leave-one-volunteer-out;
- macro-F1 and accuracy;
- simple Logistic Regression semantic baseline versus evolving neuro-fuzzy semantic learner.

The purpose is not to prove neuro-fuzzy superiority by default. The comparison tests whether the persistent fuzzy representation is a useful carrier of expert semantics.

### RQ3 — Rule semantic evolution

As expert evidence accumulates across rounds, do persistent fuzzy rules become semantically more stable?

Candidate longitudinal signals:

- increase in top-label support;
- decrease in semantic entropy;
- changes in top semantic label;
- growth in number of supporting expert votes;
- persistence of mixed/high-entropy rules.

`semantic_rule_evolution_events.csv` is designed to quantify these changes.

### RQ4 — Model uncertainty versus human uncertainty

Do low-coverage or fuzzy-novel cases also produce more human disagreement or explicit abstention?

`case_rule_human_signals.csv` links human semantic uncertainty to hidden fuzzy coverage, rule ID, cluster, and original selection stratum.

This permits distinctions such as:

```text
low model certainty + high human agreement   -> model limitation
high model certainty + high human disagreement -> possible semantic overconfidence
low model certainty + high human disagreement  -> intrinsically difficult / weakly represented case
```

### RQ5 — Active acquisition efficiency

Does selecting later annotations from semantic uncertainty + fuzzy novelty improve semantic generalization more efficiently than arbitrary additional labels?

The current selector uses:

```text
0.7 * semantic uncertainty + 0.3 * fuzzy novelty
```

A later paper analysis can compare performance/semantic entropy as a function of cumulative expert queries across rounds.

## Phase separation

### Phase A — semantic evolution

Keep Gaussian rule premises fixed and update the semantic evidence attached to persistent rule IDs.

### Phase B — structural evolution

Only after persistent semantic conflict is demonstrated should a separate experiment test actions such as rule split, child-rule creation, new-rule birth, or premise adaptation.

Keeping these phases separate makes it possible to determine whether existing visual geometry already contains reusable anatomy before allowing expert labels to reshape that geometry.


## Partial-review policy

Reviewer completion is not required to be identical. If one expert reviews 30 photographs and another reviews 48, the 18 unreviewed cases for the first expert remain `not_started`. They are excluded from pairwise agreement for that expert pair. They may still have `single_rater` semantic labels from the second expert and are excluded from the stricter `multi_rater_high_consensus` sensitivity subset until a second valid opinion is available.

Missing review, `uncertain`, `not_assessable`, and `not_applicable` are therefore four distinct analytical states.
