# SOFTWARE QA ONLY — unequal reviewer completion

This folder is a software regression test, **not a scientific result**.

Synthetic QA reviewer A was truncated to 30/48 completed photographs while synthetic QA reviewer B retained 48/48. The v2.2 Admin code correctly reported:

- QA partial reviewer: 30 started, 30 complete, 18 not started;
- QA full reviewer: 48 started, 48 complete;
- pairwise agreement overlap: 30 photographs, not 48;
- photographs 31–48: one started reviewer and one `not_started` reviewer;
- `not_started` rows were not converted to `uncertain`;
- single-rater labels remain available for exploratory/all-resolved analyses but are not multi-rater evidence.

Run `python scripts/self_test_partial_raters.py` to reproduce the regression test.
