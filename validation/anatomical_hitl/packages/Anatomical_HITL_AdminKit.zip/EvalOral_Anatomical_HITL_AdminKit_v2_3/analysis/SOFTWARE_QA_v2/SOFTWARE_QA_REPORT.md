# SOFTWARE QA v2 report

All files in this directory use **synthetic deterministic labels for software testing only**. They are not dental annotations and must never be reported as scientific results.

Verified end-to-end operations:

- three independent synthetic raters were ingested without manual concatenation;
- Round 1 contains 3 × 48 complete synthetic reviews;
- a synthetic Round 2 revision for one rater/case subset was added to test longitudinal state handling;
- the current-state logic retained the most recent annotation per `rater_id + case_id` while preserving earlier rounds in history;
- `uncertain`, `not_assessable`, and `not_applicable` remained distinct states;
- pairwise agreement and consensus outputs were generated;
- rule-linked semantic profiles and `rule_semantic_state.json` were generated;
- semantic history produced 90 synthetic rule/field evolution events across R1 → R2;
- leave-one-volunteer-out Logistic Regression and evolving neuro-fuzzy analyses executed;
- new-case selector generated 24 candidates;
- re-review selector generated 12 cases with explicit reasons;
- reviewer kit self-test verifies 48/48 image files and v2 schema;
- reviewer JavaScript passes a Node syntax check.

All metric values under `analysis_output/` are QA artifacts only.
