# PCA Semantic Explorer — author-side only

This figure shows real images at the low and high extremes of PC1--PC4 for the content-deduplicated corpus. It is intentionally kept out of the blinded reviewer pack because showing these patterns before annotation could bias semantic judgments.

The figure should be interpreted as a hypothesis generator, not as evidence that a principal component has a single dental meaning. A principal component is a linear combination of the original visual descriptors and may mix illumination, framing, view, exposed dentition, instruments, and anatomy.

After independent expert annotation is returned, the authors can test whether the new semantic labels (arch, side, anterior/posterior region, tooth group) vary systematically along each principal component. This is the appropriate point to ask whether, for example, PC2 is associated with broad occlusal exposure or PC3 with lateral framing.
